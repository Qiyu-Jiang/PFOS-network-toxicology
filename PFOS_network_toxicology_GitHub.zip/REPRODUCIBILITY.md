# REPRODUCIBILITY.md — Number → Script → Output mapping

Every key number in the manuscript maps to the outputs listed below. All scripts are under `code/`.

## Pipeline outputs

| Manuscript number | Script | Output file |
|---|---|---|
| 8,788 PFOS targets / 1,053 disease targets / 389 intersection | `step01_targets/*.py` + `step02_network/04_intersection.py` | `results/TableS1_intersection_genes.csv` |
| 346 nodes / 2,300 edges / 107 hubs (degree ≥ 14 = 2×median 7) | `step02_network/05_string_ppi_network.py` | `results/TableS4_PPI_topology.csv`, `results/TableS4b_STRING_edges.csv` |
| 10 modules (M6=80-TNF … M5=4-CLGN) | `step02_network/05_string_ppi_network.py` | `results/TableS5_louvain_modules.csv` |
| KEGG intersect 129 significant (min 6.01e-11) | `step02_network/06_enrichment.py` | `results/TableS6_KEGG_2021_Human_intersect.csv` |
| KEGG hubs 168 significant (min 5.88e-24) | Same (hub gene set) | `results/TableS6_KEGG_hubs.csv` |
| GO BP 2,446 terms / 210 significant | Same | `results/TableS6_GO_Biological_Process_2023_intersect.csv` |
| 1,280 DEG (408↑/872↓) | `step03_geo_ml/09_deg_noa.py` (Gemma matrix) | `data/GSE45885_DEGs_reproduced.csv` |
| 140 ML candidates (389 ∩ p<0.05) | `updates_v3/11_ml_routeA_frozen.py` | `results/ml_routeA_frozen.json`, `results/TableS7c_seed_stability.csv` |
| 4-gene consensus panel 5/5 × 5 seeds | Same | Same |
| Docking 3-seed reproducibility (SD 0.016-0.121) | `step06_qc/22_qc_vina_reproducibility.py` (superseded) | `data/docking/seeds3/docking_3seeds_summary.csv` |
| LOOCV 93.5% / 85.6% / 0.94-0.95 / cm [[3,1],[1,26]] | `updates_v3/12_cv_consensus_panel.py` | `results/loocv_panel4.json`, `results/cv_panel4_real.json` |
| Medaka DEG (correct grouping: dose 1 vs dose 2/3 pooled; 22,941 source rows, 7,949 of them without a gene symbol) | `updates_v3/10_deg_medaka_FULL.py` | `results/TableS3_medaka_DEG_recalculated.csv` (the delivered table **is** this script's own output: 14,471 genes analysed after case-insensitive deduplication and removal of one gene with zero counts in both groups (U6); columns gene/log2FC/p_value/FDR/significant/note) and `results/TableS3_medaka_DEG_matched.csv` (389-set subset: 225 genes testable, 1 nominal hit = map3k5, 0 survive BH-FDR) |
| Docking energies 11 targets | `step04_docking/*.py` + `updates_v3/13,14*.py` | `results/TableS8_docking_summary.csv`, `data/docking/` |

## Input data (data/)

| File | Source | Purpose |
|---|---|---|
| `data/CTD_annotated_summary.csv` | CTD base (ctdbase.org, 2026-07-25) | Upstream for 8,787 PFOS targets (taxonomy-filtered) |
| `data/GSE287960_testis_normExpr_DESeq2.tsv.gz` | NCBI GEO GSE287960 | Medaka DEG (Ensembl ID + gene_name columns) |
| `data/GSE45885_expression_by_gene_gemma.csv` | Gemma dataset GSE45885 (gemma.msl.ubc.ca) | DEG replication / ML / Table 3 |
| `data/docking/` | Receptor PDBQT, PFOS ligand, Vina poses and logs | Table 4 |
| `data/GSE45885_DEGs_reproduced.csv` | Generated from Gemma matrix | 140 candidates, Table 3 |
| `results/TableS3_medaka_DEG_recalculated.csv` | Recalculated medaka DEG (correct grouping; 14,471 genes) | Table 5, Section 3.6 |

## Environment and seeds

- Python 3.11+, scikit-learn v1.5.2, pandas, scipy, statsmodels (see requirements.txt)
- Fixed seeds: 0, 42, 123, 2024, 31415 (ML); Vina deterministic; FUS site-specific 4 seeds

## Database access dates

- CTD base: downloaded 2026-07-25 (ctdbase.org)
- GEO GSE45885 and GSE287960: accessed 2026-07/08 (ncbi.nlm.nih.gov/geo)
- Gemma: accessed 2026-08 (gemma.msl.ubc.ca)
- MalaCards: accessed 2026-07 (malacards.org) — export not included in repo; see data/README.md for details
- OpenTargets: accessed 2026-07 (opentargets.org) — export not included in repo
- SwissTargetPrediction: accessed 2026-07 (swisstargetprediction.ch) — export not included in repo
