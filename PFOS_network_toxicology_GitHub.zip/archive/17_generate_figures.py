#!/usr/bin/env python3
"""
Step 17: 生成论文图1-7 (journal-style
========================================
规格: 300 DPI, 单栏85mm(3.35in), 双栏170mm(6.69in),
      font.size=8, axes.labelsize=9, savefig.bbox='tight'
      字体Liberation Sans(视觉等同Arial, 投稿系统无Arial时fallback)

输入:  data_analysis/ 下各结果CSV
输出:  manuscript/figures/Figure1-7.png

依赖: pandas matplotlib matplotlib_venn networkx
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pathlib import Path

BASE = Path("data")
OUT = Path("./manuscript/figures")
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Liberation Sans", "DejaVu Sans"],
    "font.size": 8, "axes.labelsize": 9,
    "savefig.dpi": 300, "savefig.bbox": "tight",
})

BLUE, RED, GREEN, ORANGE = "#3B82F6", "#DC2626", "#16A34A", "#D97706"


def fig1_workflow():
    """研究流程图。"""
    fig, ax = plt.subplots(figsize=(6.69, 5.2))
    ax.axis("off")
    boxes = [
        (0.5, 0.93, "PFOS targets\nCTD (5,846) + SwissTargetPrediction (11)\n= 5,847 genes", BLUE),
        (0.5, 0.76, "Spermatogenic dysfunction targets\nMalaCards (517) + OpenTargets (738) + CTD (107)\n= 986 genes", GREEN),
        (0.5, 0.59, "Intersection\n379 genes", ORANGE),
        (0.5, 0.42, "PPI network (STRING v12.0)\n101 hub genes (degree ≥ 2×median) | 9 modules\nGO/KEGG enrichment (Enrichr)", ORANGE),
        (0.5, 0.25, "GSE45885 DEGs (NOA vs control)\n∩ 379 → 114 candidates\nLASSO ∩ RF → 8 biomarkers", RED),
        (0.5, 0.08, "Validation\nAutoDock Vina docking + GSE287960 cross-species", "#6B7280"),
    ]
    for x, y, text, color in boxes:
        ax.add_patch(FancyBboxPatch((x - 0.38, y - 0.055), 0.76, 0.11,
                     boxstyle="round,pad=0.01", fc="white", ec=color, lw=1.4))
        ax.text(x, y, text, ha="center", va="center", fontsize=7.5)
    for i in range(len(boxes) - 1):
        ax.add_patch(FancyArrowPatch((0.5, boxes[i][1] - 0.058),
                                     (0.5, boxes[i + 1][1] + 0.058),
                                     arrowstyle="-|>", mutation_scale=12,
                                     color="#94A3B8"))
    fig.savefig(OUT / "Figure1_workflow.png")
    plt.close(fig)


def fig2_venn():
    """PFOS与疾病靶点Venn图。"""
    from matplotlib_venn import venn2
    pfos = set(pd.read_csv(BASE / "pfos_targets_all.csv")["GeneSymbol"])
    dis = set(pd.read_csv(BASE / "disease_targets_merged.csv")["GeneSymbol"])
    inter = len(pfos & dis)
    fig, ax = plt.subplots(figsize=(3.35, 3.0))
    venn2((pfos, dis), set_labels=("PFOS targets", "Disease targets"),
          set_colors=(BLUE, GREEN), alpha=0.6, ax=ax)
    ax.set_title(f"Intersection: {inter} genes")
    fig.savefig(OUT / "Figure2_venn.png")
    plt.close(fig)


def fig3_ppi_hub():
    """PPI网络: top hub基因度分布条形图。"""
    top = pd.read_csv(BASE / "ppi_topology.csv").head(20)
    fig, ax = plt.subplots(figsize=(3.35, 4.2))
    colors = [BLUE if d >= 14 else "#93C5FD"
              for d in top["Degree"]]
    ax.barh(top["GeneSymbol"][::-1], top["Degree"][::-1], color=colors[::-1])
    ax.axvline(14, color=RED, ls="--", lw=1)
    ax.text(14.5, 1, "hub cutoff\n(2×median=14)", fontsize=7, color=RED)
    ax.set_xlabel("Degree")
    ax.set_title("STRING PPI: top 20 genes")
    fig.savefig(OUT / "Figure3_ppi_hub.png")
    plt.close(fig)


def fig4_kegg():
    """KEGG富集top15气泡/条形图。"""
    kegg = pd.read_csv(BASE / "enrichment/intersect379_KEGG.csv").head(15)
    kegg["label"] = kegg["Term"].str.slice(0, 38)
    y = np.arange(len(kegg))[::-1]
    sizes = -np.log10(kegg["Adjusted P-value"].clip(lower=1e-30))
    fig, ax = plt.subplots(figsize=(6.69, 4.2))
    sc = ax.scatter(kegg["Odds Ratio"], y, s=sizes * 8 + 10,
                    c=-np.log10(kegg["P-value"]), cmap="RdYlBu_r",
                    edgecolors="#334155", linewidths=0.4)
    ax.set_yticks(y, kegg["label"], fontsize=7)
    ax.set_xscale("log")
    ax.set_xlabel("Odds ratio (log scale)")
    ax.set_title("KEGG enrichment (379 intersection genes)")
    plt.colorbar(sc, ax=ax, label="-log10(P)", shrink=0.7)
    fig.savefig(OUT / "Figure4_kegg.png")
    plt.close(fig)


def fig5_ml_selection():
    """LASSO系数 + RF重要性。"""
    lasso = pd.read_csv(BASE / "ml_lasso_selected.csv", index_col=0)
    rf = pd.read_csv(BASE / "ml_rf_selected.csv", index_col=0)
    rf15 = rf.head(15)
    fig, axes = plt.subplots(1, 2, figsize=(6.69, 3.2))
    axes[0].barh(lasso.index[::-1], lasso.iloc[::-1, 0], color=BLUE)
    axes[0].set_title("LASSO coefficients")
    axes[0].set_xlabel("Coefficient")
    axes[1].barh(rf15.index[::-1], rf15.iloc[::-1, 0], color=ORANGE)
    axes[1].set_title("RF importance (top 15)")
    axes[1].set_xlabel("Importance")
    fig.tight_layout()
    fig.savefig(OUT / "Figure5_ml_selection.png")
    plt.close(fig)


def fig6_docking():
    """对接结合能条形图。"""
    dock = pd.read_csv(BASE / "docking/results/docking_summary.csv")
    dock = dock[dock["Best_affinity"].notna()].sort_values("Best_affinity")
    colors = [RED if e <= -7 else (ORANGE if e <= -5 else "#9CA3AF")
              for e in dock["Best_affinity"]]
    fig, ax = plt.subplots(figsize=(3.35, 2.8))
    ax.barh(dock["Gene"], dock["Best_affinity"], color=colors)
    ax.axvline(-5, color="#6B7280", ls="--", lw=0.8)
    ax.axvline(-7, color=RED, ls="--", lw=0.8)
    ax.set_xlabel("Binding affinity (kcal/mol)")
    ax.set_title("PFOS-target docking (Vina)")
    fig.savefig(OUT / "Figure6_docking.png")
    plt.close(fig)


def fig7_cross_species():
    """跨物种方向一致性对比图。"""
    biom = pd.read_csv(BASE / "ml_final_biomarkers.csv")
    med = pd.read_csv(BASE / "geo/pfos_validation/GSE287960_PFOS_DEGs.csv")
    med_idx = med.set_index(med["gene"].str.lower())
    genes, human_lfc, med_lfc = [], [], []
    for _, r in biom.iterrows():
        g = r["GeneSymbol"]
        if g.lower() in med_idx.index:
            m = med_idx.loc[g.lower()]
            if isinstance(m, pd.DataFrame):
                m = m.iloc[0]
            genes.append(g)
            human_lfc.append(r["DEG_log2FC"])
            med_lfc.append(m["log2FC"])
    x = np.arange(len(genes))
    fig, ax = plt.subplots(figsize=(3.35, 2.8))
    ax.bar(x - 0.18, human_lfc, 0.36, label="Human NOA", color=BLUE)
    ax.bar(x + 0.18, med_lfc, 0.36, label="Medaka PFOS", color=GREEN)
    ax.axhline(0, color="#334155", lw=0.8)
    ax.set_xticks(x, genes, fontsize=7, rotation=45, ha="right")
    ax.set_ylabel("log2FC")
    ax.set_title("Cross-species expression direction")
    ax.legend(fontsize=7)
    fig.savefig(OUT / "Figure7_cross_species.png")
    plt.close(fig)


def main():
    fig1_workflow();  print("Figure1 ✓")
    fig2_venn();      print("Figure2 ✓")
    fig3_ppi_hub();   print("Figure3 ✓")
    fig4_kegg();      print("Figure4 ✓")
    fig5_ml_selection(); print("Figure5 ✓")
    fig6_docking();   print("Figure6 ✓")
    fig7_cross_species(); print("Figure7 ✓")
    print(f"\n全部输出至 {OUT}")


if __name__ == "__main__":
    main()
