#!/usr/bin/env python3
"""
Step 12: 跨物种验证 (medaka PFOS暴露 ↔ 人NOA标志物)
=====================================================
比较8个生物标志物在两个数据集中的表达方向:
  - 人NOA (GSE45885): log2FC方向
  - 青鳉鱼PFOS暴露 (GSE287960): 直系同源基因(小写符号)log2FC方向

结果(论文报告):
  3个标志物有medaka直系同源: OSBP2, PARK7, NOS1
  方向一致: OSBP2 (双下调), PARK7 (双上调) → 2/3
  方向不一致: NOS1 (NOA下调 vs PFOS上调) → 见Discussion局限说明
  另有4个379交集基因在medaka中p<0.05: e2f1, cip2a, prkg1, scml2

输入:  data_analysis/ml_final_biomarkers.csv
       data_analysis/geo/GSE45885_DEGs_NOA_vs_control.csv
       data_analysis/geo/pfos_validation/GSE287960_PFOS_DEGs.csv
输出:  控制台报告 (结果已写入论文Results 3.6)

依赖: pandas
"""
import pandas as pd
from pathlib import Path

BASE = Path("data")


def main():
    biomarkers = pd.read_csv(BASE / "ml_final_biomarkers.csv")
    noa = pd.read_csv(BASE / "geo/GSE45885_DEGs_NOA_vs_control.csv")
    med = pd.read_csv(BASE / "geo/pfos_validation/GSE287960_PFOS_DEGs.csv")
    med_idx = med.set_index(med["gene"].str.lower())

    print("=" * 72)
    print("跨物种方向一致性 (人NOA vs medaka PFOS暴露)")
    print("=" * 72)
    n_match, n_concord = 0, 0
    for _, row in biomarkers.iterrows():
        g = row["GeneSymbol"]
        noa_dir = row["direction"]
        noa_lfc = row["DEG_log2FC"]
        if g.lower() in med_idx.index:
            m = med_idx.loc[g.lower()]
            if isinstance(m, pd.DataFrame):
                m = m.iloc[0]
            med_dir = m["direction"]
            med_lfc = m["log2FC"]
            concord = noa_dir == med_dir
            n_match += 1
            n_concord += int(concord)
            print(f"  {g:>8}: NOA log2FC={noa_lfc:+.3f} ({noa_dir}) | "
                  f"medaka log2FC={med_lfc:+.3f} ({med_dir}) | "
                  f"{'一致' if concord else '不一致 ✗'}")
        else:
            print(f"  {g:>8}: NOA log2FC={noa_lfc:+.3f} ({noa_dir}) | "
                  f"medaka无直系同源注释")

    print(f"\n方向一致: {n_concord}/{n_match}")

    # 379交集中medaka p<0.05的基因
    inter = pd.read_csv(BASE / "pfos_disease_intersection.csv")
    matched = med[med["gene"].str.lower().isin(
        inter["GeneSymbol"].str.lower()) & (med["p_value"] < 0.05)]
    print(f"\n379交集基因中medaka p<0.05: {matched['gene'].tolist()}")


if __name__ == "__main__":
    main()
