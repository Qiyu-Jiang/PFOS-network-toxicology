#!/usr/bin/env python3
"""
Step 10: GSE287960跨物种验证数据准备 (青鳉鱼PFOS暴露DEG)
==========================================================
数据: 青鳉鱼睾丸PFOS暴露转录组(supplementary normExpr.tsv.gz, 线性尺度),
      18样本, 列命名TBR/TCR×A/B/C:
        TBR = BPA谱系, TCR = 对照谱系
        后缀A = PFOS 0 mg/L (对照), B = 0.002 mg/L, C = 0.02 mg/L
      对照组 = 6个后缀A样本, PFOS组 = 12个后缀B/C样本
      ⚠ 不能按列位置分组(tsv列序与GSM序不同)
统计: Welch t检验(线性值) + BH FDR
      log2FC = log2(mean_PFOS / mean_control)   ← 线性数据标准公式
      significant: FDR < 0.05
      跨物种方向比对用名义 p < 0.05

注意: supplementary tsv.gz可能下载不完整(gzip EOFError),
      逐行容错读取; 分析时存档版本为4,611个唯一基因名。

输入:  data_analysis/geo/pfos_validation/GSE287960_normExpr.tsv.gz
输出:  data_analysis/geo/pfos_validation/GSE287960_PFOS_DEGs.csv
       data_analysis/geo/pfos_validation/PFOS_DEG_matched_379.csv

依赖: pandas scipy statsmodels
"""
import gzip
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
from pathlib import Path

DIR = Path("data/geo/pfos_validation")
P_MATCH = 0.05   # 跨物种比对用名义p值


def read_tsv_gz_safe(path):
    """逐行读取(容忍截断的gz文件)。
    列: ENSEMBL_GeneID, gene_name, 18个样本列(TBR1A...TCR3C)"""
    rows = []
    with gzip.open(path, "rt", errors="ignore") as f:
        try:
            header = f.readline().rstrip("\n").split("\t")
            for line in f:
                parts = line.rstrip("\n").split("\t")
                if len(parts) == len(header):
                    rows.append(parts)
        except EOFError:
            print(f"⚠ 文件截断, 已读取{len(rows)}行")
    return header, rows


def main():
    header, rows = read_tsv_gz_safe(DIR / "GSE287960_normExpr.tsv.gz")
    samples = header[2:]
    print(f"读取 {len(rows)}行, {len(samples)}样本列")

    # ── 分组: 后缀A=对照(0 mg/L), B/C=PFOS ──
    controls = [c for c in samples if c.endswith("A")]
    pfos = [c for c in samples if not c.endswith("A")]
    ctrl_idx = [samples.index(c) for c in controls]
    pfos_idx = [samples.index(c) for c in pfos]
    print(f"control n={len(controls)} ({controls}), PFOS n={len(pfos)}")

    # ── DEG: 基因名去重(保留首个), 线性值Welch t检验 ──
    genes, lfc, pvals = [], [], []
    seen = set()
    for r in rows:
        gname = r[1]
        if not gname or gname.lower() in seen:
            continue
        seen.add(gname.lower())
        vals = np.array([float(x) for x in r[2:]])
        c, p = vals[ctrl_idx], vals[pfos_idx]
        if np.allclose(c, 0) and np.allclose(p, 0):
            continue
        t, pv = stats.ttest_ind(p, c, equal_var=False)
        genes.append(gname)
        lfc.append(np.log2(p.mean() / c.mean()) if c.mean() > 0 else np.nan)
        pvals.append(pv)

    res = pd.DataFrame({"gene": genes, "log2FC": lfc, "p_value": pvals})
    _, fdr, _, _ = multipletests(res["p_value"].fillna(1), method="fdr_bh")
    res["FDR"] = fdr
    res["significant"] = res["FDR"] < 0.05
    res["direction"] = np.where(res["log2FC"] > 0, "up", "down")
    res.to_csv(DIR / "GSE287960_PFOS_DEGs.csv", index=False)
    print(f"已保存 {len(res)}基因 → GSE287960_PFOS_DEGs.csv")
    print(f"FDR<0.05显著: {res['significant'].sum()} "
          f"(环境剂量下效应量小, 主要用名义p<0.05做方向比对)")

    # ── 与379交集匹配 (medaka小写 ↔ 人大写) ──
    inter = pd.read_csv("data/"
                        "pfos_disease_intersection.csv")
    res["lower"] = res["gene"].str.lower()
    matched = res[res["lower"].isin(
        inter["GeneSymbol"].str.lower())].copy()
    sig_matched = matched[matched["p_value"] < P_MATCH]
    sig_matched.drop(columns=["lower"]).to_csv(
        DIR / "PFOS_DEG_matched_379.csv", index=False)
    print(f"379交集中有medaka直系同源: {len(matched)}, "
          f"其中 p<{P_MATCH}: {len(sig_matched)} → PFOS_DEG_matched_379.csv")


if __name__ == "__main__":
    main()
