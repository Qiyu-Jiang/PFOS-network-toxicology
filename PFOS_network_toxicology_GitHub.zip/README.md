# PFOS-induced spermatogenic dysfunction: network toxicology, machine learning, and cross-species comparison

Analysis code and intermediate results for the manuscript:

> **Network Toxicology Integration of Multi-Database Mining, Machine Learning, and Molecular Docking Computationally Prioritizes Candidate Genes Potentially Linking PFOS Exposure to Spermatogenic Dysfunction**

The pipeline integrates multi-database target mining (CTD, SwissTargetPrediction, MalaCards,
OpenTargets), PPI network analysis (STRING v12.0, Louvain modularity), differential expression
of two GEO datasets (GSE45885 human NOA; GSE287960 medaka PFOS exposure), a frozen multi-seed
machine learning consensus pipeline (LASSO + random forest, five fixed seeds: 0, 42, 123,
2024, 31415), and AutoDock Vina molecular docking (consensus panel receptors plus
network-prioritized targets, including site-specific docking at the FUS zinc-finger
RNA-binding pocket).

**Primary output**: a four-gene consensus panel (REC8, DNAH1, GAPDHS, COX6B2), all selected
by both algorithms in 5/5 seeds, with network-prioritized targets (OSBP2, ACE, FUS, CXXC1)
reported separately.

## Repository structure

```
code/
  step01_targets/       target & disease gene collection (CTD, mygene, OpenTargets, MalaCards)
  step02_network/       intersection, STRING PPI, topology, Louvain modules
  step03_geo_ml/        GEO processing, DEG analysis, LASSO/RF, cross-species comparison
  step04_docking/       receptor/ligand preparation, Vina docking, FUS site-specific docking
  step06_qc/            QC and reproducibility scripts (20/21/22); outputs in results/
  updates_v3/           scripts superseding archived versions during revision
                        10_deg_medaka_FULL.py            full-file medaka DEG rerun (dose 1 vs dose 2/3; 14,471 genes analysed)
                        11_ml_routeA_frozen.py          frozen multi-seed consensus pipeline (route A)
                        12_cv_consensus_panel.py        cross-validation of the 4-gene consensus panel
                        13_prepare_receptors_new_panel.py  AlphaFold v6 receptor prep (GAPDHS/COX6B2/REC8)
                        14_dock_new_panel.py            Vina docking of GAPDHS and COX6B2
results/                intermediate result tables (inputs to the Supplementary Material)
                        TableS7a_LASSO_seed_selection.csv    140 candidates x 5 seeds selection matrix
                        TableS7b_RF_importance_seeds.csv     140 candidates x 5 seeds RF importance
                        TableS7c_seed_stability.csv          per-gene seed frequencies (LASSO/RF/both)
                        TableS8_docking_summary.csv          11-receptor docking summary (tiered)
                        ml_routeA_frozen.json                frozen-pipeline run record
                        cv_panel4_real.json                  5-fold CV of the 4-gene panel
data/docking/seeds3/    3-seed replicate docking (authoritative reproducibility evidence)
data/README.md          how to obtain each external dataset (versions & dates)
archive/                superseded scripts and tables retained for provenance
```

## Requirements

Python 3.11+ with:

```
pip install -r requirements.txt
```

Molecular docking additionally requires the AutoDock Vina 1.2.7 executable
(place as `bin/vina.exe`) and, for ligand preparation, `rdkit` and `meeko`.

## Reproduction

Run the steps in numerical order (`step01` -> `step06`). Key notes:

1. **Step 10 (medaka DEG)** uses the FULL GSE287960 supplementary matrix
   (22,941 gene rows); use `updates_v3/10_deg_medaka_FULL.py`, which verifies
   gzip integrity before analysis (an earlier truncated download of 4,611 genes
   is superseded).
2. **Machine learning (route A, frozen)**: `updates_v3/11_ml_routeA_frozen.py`
   re-runs LASSO + random forest on the 140 ML candidates (389 intersection
   ∩ reproduced DEG p < 0.05) with five fixed seeds; consensus = genes selected
   by both algorithms in >= 4/5 seeds. `updates_v3/12_cv_consensus_panel.py`
   reproduces the 5-fold cross-validation of the 4-gene panel
   (accuracy 93.6% +/- 0.2%; balanced accuracy 85.6%; AUC 0.954).
3. **Docking**: consensus receptors GAPDHS (AF-O14556-F1) and COX6B2
   (AF-Q6YFQ2-F1) are docked with whole-protein geometric-center boxes
   (25 A, exhaustiveness 32) via `updates_v3/13_...` and `14_...`.
   REC8 (AF-O95072-F1) is docked identically. DNAH1 (Q9P2D7) has no
   AlphaFold v6 model (4,644 aa) and was not docked.
   FUS uses MODEL 1 of the NMR ensemble 6G99 (zinc-finger/RNA pocket, 596
   protein atoms) with site-specific search-box placement; four random seeds
   are reported.
4. **CTD filtering** uses MyGene.info taxid=9606 mapping; the archived pipeline
   used an equivalent GeneID < 55,000 cutoff (see Methods of the manuscript).
5. Figures are regenerated with `updates_v3/17_generate_figures_v3.py`
   (superseded figures reflect the earlier single-run 8-gene panel).

## Data availability

All external datasets are publicly available (see `data/README.md` for exact
files, versions, and download dates). GEO accessions: GSE45885, GSE287960.

## License

MIT (see `LICENSE`). External database content is subject to the respective
database policies (CTD, OpenTargets, MalaCards are cited in the manuscript).

## Citation

If you use this pipeline, please cite the manuscript (citation details will be
updated upon publication) and the underlying databases (CTD, STRING, OpenTargets,
AlphaFold DB).
