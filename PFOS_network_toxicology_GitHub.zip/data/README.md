# External data sources

All input data are publicly available. Download to `data/` before running.

| File | Source | Version / date | Notes |
| --- | --- | --- | --- |
| GSE45885 (RAW tar, 123 MB) | NCBI GEO `GSE45885` suppl | accessed 2026-08 | 31 CEL files, Affymetrix HuGene 1.0 ST |
| GSE287960_normExpr_DESeq2.tsv.gz | NCBI GEO `GSE287960` suppl | accessed 2026-08 | full matrix, 22,941 rows; verify gzip integrity |
| CTD_C076994_genes.csv | CTD web export (chemical C076994 = PFOS) | 2026-07-25 | 10,138 gene rows, all organisms |
| CTD_curated_genes_diseases.csv.gz | CTD reports | 2026-07 release | curated gene-disease associations |
| CTD_chem_gene_ixns.csv.gz | CTD reports | 2026-07 | cross-check of PFOS human targets |
| MalaCards gene lists (4 files) | malacards.org | 2026-07 | Azoospermia; Male Infertility; Male Infertility (single-gene); Spermatogenic Failure |
| OpenTargets associatedTargets | platform.opentargets.org GraphQL API | 2026-08 | 18 disease IDs, score >= 0.1 |
| SwissTargetPrediction.csv | swisstargetprediction.ch | 2026-07 | PFOS canonical SMILES (PubChem CID 74483) |
| PDB 1O8A / 1P5F / 4D1N / 6G99 | rcsb.org | accessed 2026-08 | docking receptors |
| AlphaFold AF-O14556-F1 / AF-Q6YFQ2-F1 / AF-O95072-F1 / AF-Q8IZU9-F1 / AF-Q969R2-F1 / AF-Q9P0U4-F1 (v6) | alphafold.ebi.ac.uk | accessed 2026-08 | docking receptors: GAPDHS / COX6B2 / REC8 / KIRREL3 / OSBP2 / CXXC1 (predicted) |
| PubChem CID 74483 3D SDF | pubchem.ncbi.nlm.nih.gov | accessed 2026-08 | PFOS ligand (3D) |

Version note: CTD is continuously updated; counts drift over time (e.g., PFOS
human targets 5,846 archived vs 8,787 with current release under taxonomy
filtering). The intersection is robust to this drift: all candidate
biomarkers and all three-database core genes are retained.
