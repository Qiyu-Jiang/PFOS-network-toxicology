# NOTE: This script is SUPERSEDED by data/docking/seeds3/ (authoritative 3-seed replicate
# docking results, summarized in data/docking/seeds3/docking_3seeds_summary.csv).
# It is retained for provenance only.
#!/usr/bin/env python3
"""QC第4项：Vina对接重现性测试 - 重跑3次ACE/OSBP2/REC8/NOS1"""
import os, sys, numpy as np
from vina import Vina

rec_dir = "data/docking"
lig = "data/docking/pfos_ligand.pdbqt"
results_dir = "data/docking/qc_repro"
os.makedirs(results_dir, exist_ok=True)

def get_center(pdbqt):
    coords = []
    with open(pdbqt) as f:
        for line in f:
            if line.startswith('ATOM'):
                try:
                    coords.append([float(line[30:38]),float(line[38:46]),float(line[46:54])])
                except: pass
    c = np.mean(coords, axis=0)
    return [round(float(c[0]),1), round(float(c[1]),1), round(float(c[2]),1)]

targets = [
    ('ACE', 'ACE_1O8A.pdbqt', 25),
    ('OSBP2', 'OSBP2_AF.pdbqt', 25),
    ('REC8', 'REC8_AF.pdbqt', 25),
    ('NOS1', 'NOS1_4D1N.pdbqt', 20),
    ('KIRREL3', 'KIRREL3_AF.pdbqt', 25),
    ('PARK7', 'PARK7_1P5F.pdbqt', 25),
    ('CXXC1', 'CXXC1_AF.pdbqt', 25),
]

original = {'ACE': -7.954, 'OSBP2': -7.561, 'NOS1': -6.775,
            'KIRREL3': -4.364, 'CXXC1': -6.888, 'REC8': -5.412, 'PARK7': -1.443}

log_path = os.path.join(results_dir, "vina_repro_log.txt")
log = open(log_path, 'w')
log.write("Vina Reproducibility Test\n")
log.write(f"Targets: {[t[0] for t in targets]}\n")
log.write(f"Parameters: exhaustiveness=32, n_poses=5, 3 repeats per target\n")
log.write(f"{'Gene':>8} | {'Original':>8} | {'Run1':>8} | {'Run2':>8} | {'Run3':>8} | {'Mean':>8} | {'Std':>6} | {'MaxDiff':>8}\n")
log.write("-" * 80 + "\n")
log.flush()

print("Vina Reproducibility Test")
print(f"{'Gene':>8} | {'Original':>8} | {'Run1':>8} | {'Run2':>8} | {'Run3':>8} | {'Mean':>8} | {'Std':>6}")
print("-" * 75)

for gene, rec_file, box_size in targets:
    rec_path = os.path.join(rec_dir, rec_file)
    if not os.path.exists(rec_path):
        log.write(f"{gene:>8} | FILE NOT FOUND\n")
        continue

    center = get_center(rec_path)
    energies = []

    for run in range(3):
        try:
            v = Vina(sf_name='vina')
            v.set_receptor(rec_path)
            v.set_ligand_from_file(lig)
            v.compute_vina_maps(center=center, box_size=[box_size]*3)
            v.dock(exhaustiveness=32, n_poses=5)
            best = v.energies()[0][0]
            energies.append(round(best, 3))
            log.write(f"  {gene} run{run+1}: {best:.3f} kcal/mol\n")
            log.flush()
        except Exception as e:
            log.write(f"  {gene} run{run+1}: ERROR: {e}\n")
            log.flush()
            energies.append(None)

    orig = original.get(gene, None)
    valid = [e for e in energies if e is not None]
    if valid:
        mean = np.mean(valid)
        std = np.std(valid)
        max_diff = max(abs(e - orig) for e in valid) if orig else 0
    else:
        mean = std = max_diff = 0

    e1 = energies[0] if len(energies) > 0 else None
    e2 = energies[1] if len(energies) > 1 else None
    e3 = energies[2] if len(energies) > 2 else None

    def fmt(v):
        return f"{v:>8.3f}" if v is not None else f"{'N/A':>8}"

    line = f"{gene:>8} | {fmt(orig)} | {fmt(e1)} | {fmt(e2)} | {fmt(e3)} | {fmt(mean)} | {std:>6.3f} | {max_diff:>8.3f}"
    log.write(line + "\n")
    log.flush()
    print(line)

log.write("\n" + "="*80 + "\n")
log.write("Assessment:\n")
log.write("- Stable if maxDiff < 1.0 kcal/mol and std < 0.5\n")
log.write("- Moderate if maxDiff 1.0-2.0 kcal/mol\n")
log.write("- Unstable if maxDiff > 2.0 kcal/mol\n")
log.close()
print(f"\nLog saved to {log_path}")
