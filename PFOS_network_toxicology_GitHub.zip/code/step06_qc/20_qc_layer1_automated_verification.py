#!/usr/bin/env python3
"""
Layer 1 QC: 自动化验证脚本
验证稿件中所有关键数字与CSV数据是否一致
"""
import pandas as pd
import os

BASE = "data"
PASS = 0
FAIL = 0

def check(name, expected, actual, tolerance=None):
    global PASS, FAIL
    if tolerance:
        ok = abs(expected - actual) <= tolerance
    else:
        ok = (expected == actual)
    status = "✓ PASS" if ok else "✗ FAIL"
    if ok:
        PASS += 1
    else:
        FAIL += 1
    print(f"  {status}: {name}")
    print(f"    Expected: {expected}")
    print(f"    Actual:   {actual}")
    if not ok:
        print(f"    >>> MISMATCH! <<<")

print("=" * 60)
print("  Layer 1 QC: Automated Data Verification")
print("=" * 60)

# ── 1. Intersection count ──
print("\n[1] Intersection gene count")
df = pd.read_csv(f"{BASE}/pfos_disease_intersection.csv")
check("Intersection genes", 379, len(df))

# ── 2. Three-database core genes ──
print("\n[2] Three-database core genes (MalaCards∩CTD∩OpenTargets)")
core = df[df["disease_source_count"] == 3]
expected_core = {"AR", "CFTR", "ESR1", "GPX4", "MTHFR", "NECTIN2", "SEPTIN12", "TEX11"}
actual_core = set(core["GeneSymbol"].tolist())
check("Three-DB core count", 8, len(actual_core))
check("Three-DB core genes match", expected_core, actual_core)

# ── 3. PPI hub count ──
print("\n[3] PPI Hub genes")
hub = pd.read_csv(f"{BASE}/ppi_hub_genes.csv")
check("Hub gene count", 101, len(hub))

# ── 4. Hub threshold verification ──
print("\n[4] Hub threshold (degree >= 2×median)")
# Need to verify median=7, threshold=14
# Check from hub file: min degree should be 14
min_degree = hub["Degree"].min()
check("Min hub degree (=threshold)", 14, min_degree)
# Check median: the 379 intersection had median degree 7 in the largest component
# We can verify by checking if all hubs have degree >= 14
all_above = (hub["Degree"] >= 14).all()
check("All hubs have degree >= 14", True, all_above)

# ── 5. LASSO ∩ Random Forest = 8 ──
print("\n[5] LASSO ∩ Random Forest intersection")
lasso = pd.read_csv(f"{BASE}/ml_lasso_selected.csv")
rf = pd.read_csv(f"{BASE}/ml_rf_selected.csv")
lasso_genes = set(lasso["GeneSymbol"])
rf_genes = set(rf["GeneSymbol"])
intersection = lasso_genes & rf_genes
check("LASSO selected count", 10, len(lasso_genes))
check("RF selected count (importance>0.01)", 37, len(rf_genes))
check("LASSO∩RF intersection", 8, len(intersection))

# Verify the 8 biomarkers
biomarkers = pd.read_csv(f"{BASE}/ml_final_biomarkers.csv")
actual_biomarkers = set(biomarkers["GeneSymbol"])
expected_biomarkers = {"FUS", "REC8", "CXXC1", "PARK7", "ACE", "KIRREL3", "NOS1", "OSBP2"}
check("8 biomarkers match", expected_biomarkers, actual_biomarkers)
check("Biomarker == LASSO∩RF", intersection, actual_biomarkers)

# ── 6. KEGG enrichment terms ──
print("\n[6] KEGG enrichment (intersection 379)")
kegg = pd.read_csv(f"{BASE}/enrichment/intersect379_KEGG.csv")
# Check specific terms mentioned in manuscript
terms = kegg["Term"].tolist()
for term_name in ["Prostate cancer", "Estrogen signaling pathway", "Oocyte meiosis",
                   "Steroid hormone biosynthesis", "p53 signaling pathway",
                   "Apoptosis", "Chemical carcinogenesis"]:
    found = any(term_name in t for t in terms)
    check(f"KEGG term: {term_name}", True, found)

# ── 7. DEG: 8 biomarkers in GSE45885 ──
print("\n[7] 8 Biomarkers in GSE45885 DEG list")
deg = pd.read_csv(f"{BASE}/geo/GSE45885_DEGs_NOA_vs_control.csv")
# Check each biomarker has a DEG entry
for gene in expected_biomarkers:
    gene_deg = deg[deg["GeneSymbol"] == gene]
    if len(gene_deg) > 0:
        row = gene_deg.iloc[0]
        print(f"    {gene}: log2FC={row['log2FC']:.4f}, p={row['p_value']:.4e}, direction={row['direction']}")
    else:
        print(f"    {gene}: NOT FOUND in DEG list!")
        FAIL += 1

# ── 8. Cross-species validation ──
print("\n[8] Cross-species validation (GSE287960)")
xval = pd.read_csv(f"{BASE}/geo/pfos_validation/PFOS_DEG_matched_379.csv")
check("Cross-species matched genes (from 379)", 4, len(xval))
# Check biomarker orthologs
medaka = pd.read_csv(f"{BASE}/geo/pfos_validation/GSE287960_PFOS_DEGs.csv")
for gene in ["osbp2", "nos1", "park7"]:
    found = medaka[medaka["gene"].str.lower() == gene]
    if len(found) > 0:
        row = found.iloc[0]
        print(f"    {gene}: log2FC={row['log2FC']:.3f}, p={row['p_value']:.3f}")
    else:
        # Try uppercase
        found2 = medaka[medaka["gene"].str.upper() == gene.upper()]
        if len(found2) > 0:
            row = found2.iloc[0]
            print(f"    {gene}: log2FC={row['log2FC']:.3f}, p={row['p_value']:.3f}")
        else:
            print(f"    {gene}: not in significant DEG list (may still be in full matrix)")

# ── 9. Docking results ──
print("\n[9] Molecular docking summary")
dock = pd.read_csv(f"{BASE}/docking/results/docking_summary.csv")
# Check 6/8 strong binding (≤-5.0), excluding FUS (no result) and PARK7 (weak)
dockable = dock[dock["Best_affinity"].notna()]
strong = dockable[dockable["Best_affinity"] <= -5.0]
check("Dockable targets (excl FUS)", 7, len(dockable))
check("Strong binding (≤-5.0)", 6, len(strong))
check("ACE binding energy", -7.954, dockable[dockable["Gene"]=="ACE"]["Best_affinity"].values[0], tolerance=0.001)
check("OSBP2 binding energy", -7.315, dockable[dockable["Gene"]=="OSBP2"]["Best_affinity"].values[0], tolerance=0.001)

# ── 10. Module count ──
print("\n[10] PPI module count")
modules = pd.read_csv(f"{BASE}/ppi_modules.csv")
col = "module" if "module" in modules.columns else ("Module" if "Module" in modules.columns else None)
n_modules = modules[col].nunique() if col else None
if n_modules:
    check("Module count", 9, n_modules)
else:
    print(f"    (Module column not found, columns: {list(modules.columns)})")

# ── Summary ──
print("\n" + "=" * 60)
print(f"  RESULT: {PASS} passed, {FAIL} failed")
print("=" * 60)
