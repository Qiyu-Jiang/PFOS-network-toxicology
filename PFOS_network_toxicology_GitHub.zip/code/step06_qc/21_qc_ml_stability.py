#!/usr/bin/env python3
"""
QC第3项：LASSO+RF稳定性测试
用5个不同random_state重跑，检查8个标志物的出现频率
"""
import numpy as np
import pandas as pd
from sklearn.linear_model import LassoCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
import warnings
# warnings.filterwarnings('ignore')  # commented out for transparency

print("=" * 70)
print("  ML稳定性测试：5个random_state × LASSO+RF")
print("=" * 70)

# 加载数据
expr = pd.read_csv('data_analysis/ml_candidate_expression.csv', index_col=0)
genes = expr.index.tolist()
samples = expr.columns.tolist()

# 标签：前4个是control，后27个是NOA
y = np.array([0]*4 + [1]*27)
X = expr.T.values  # samples × genes

print(f"\n数据: {X.shape[0]} samples × {X.shape[1]} genes")
print(f"Labels: {np.sum(y==0)} control, {np.sum(y==1)} NOA")

# 原始8个标志物
original_8 = {'FUS','REC8','CXXC1','PARK7','ACE','KIRREL3','NOS1','OSBP2'}

seeds = [0, 42, 123, 2024, 31415]
lasso_results = {}
rf_results = {}
intersection_results = {}

print(f"\n{'Seed':>6} | {'LASSO n':>8} | {'RF n':>6} | {'∩ n':>4} | {'8/8':>5} | {'Missing':>20}")
print("-" * 70)

for seed in seeds:
    # LASSO
    lasso = LassoCV(cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=seed),
                    random_state=seed, max_iter=10000, n_alphas=100)
    lasso.fit(X, y)
    lasso_selected = set(np.array(genes)[lasso.coef_ != 0])
    lasso_results[seed] = lasso_selected
    
    # RF
    rf = RandomForestClassifier(n_estimators=1000, max_depth=5,
                                random_state=seed, n_jobs=-1)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    cv_scores = cross_val_score(rf, X, y, cv=cv, scoring='accuracy')
    rf.fit(X, y)
    imp = pd.Series(rf.feature_importances_, index=genes)
    rf_selected = set(imp[imp > 0.01].index)
    rf_results[seed] = rf_selected
    
    # Intersection
    inter = lasso_selected & rf_selected
    intersection_results[seed] = inter
    
    # Check original 8
    missing = original_8 - inter
    n_match = len(original_8 & inter)
    
    print(f"{seed:>6} | {len(lasso_selected):>8} | {len(rf_selected):>6} | {len(inter):>4} | {n_match}/8 | {','.join(sorted(missing)) if missing else 'none':>20}")

# 稳定性统计
print(f"\n{'='*70}")
print("  稳定性统计")
print(f"{'='*70}")

# 每个原始标志物的出现频率
print(f"\n{'Gene':>10} | {'LASSO freq':>12} | {'RF freq':>10} | {'∩ freq':>8} | {'Status':>10}")
print("-" * 60)
for gene in sorted(original_8):
    lasso_count = sum(1 for s in seeds if gene in lasso_results[s])
    rf_count = sum(1 for s in seeds if gene in rf_results[s])
    inter_count = sum(1 for s in seeds if gene in intersection_results[s])
    status = "STABLE" if inter_count == 5 else ("PARTIAL" if inter_count >= 3 else "UNSTABLE")
    print(f"{gene:>10} | {lasso_count}/5{'':>7} | {rf_count}/5{'':>5} | {inter_count}/5{'':>3} | {status:>10}")

# 非原始8但偶尔出现的基因
all_inter = set()
for s in seeds:
    all_inter |= intersection_results[s]
extra = all_inter - original_8
if extra:
    print(f"\n额外出现的基因（非原始8）:")
    for gene in sorted(extra):
        count = sum(1 for s in seeds if gene in intersection_results[s])
        print(f"  {gene}: {count}/5")

# CV accuracy
print(f"\nRandom Forest CV accuracy by seed:")
for seed in seeds:
    rf = RandomForestClassifier(n_estimators=1000, max_depth=5,
                                random_state=seed, n_jobs=-1)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    scores = cross_val_score(rf, X, y, cv=cv, scoring='accuracy')
    print(f"  seed={seed}: {scores.mean():.3f} ± {scores.std():.3f}")

print(f"\n{'='*70}")
print("  结论")
print(f"{'='*70}")
stable_8 = all(gene for gene in original_8 if sum(1 for s in seeds if gene in intersection_results[s]) >= 4)
if stable_8:
    print("  所有8个标志物在≥4/5个seed中稳定出现 → ML结果可靠")
else:
    unstable = [g for g in original_8 if sum(1 for s in seeds if g in intersection_results[s]) < 4]
    print(f"  以下标志物不稳定 (<4/5): {unstable}")
    print("  → 需在Methods中说明，或考虑使用更多seed的交集")
