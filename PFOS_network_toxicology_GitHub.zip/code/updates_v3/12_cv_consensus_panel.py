# 4 基因共识面板真实 CV (修正我误写的 93.3%)
from pathlib import Path
import pandas as pd
import numpy as np
import os, json
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score, cross_val_predict
from sklearn.metrics import balanced_accuracy_score, roc_auc_score
import warnings
# warnings.filterwarnings('ignore')  # commented out for transparency

BASE = str(Path(__file__).resolve().parent.parent.parent)
RES = os.path.join(BASE, 'results')
SUPP = BASE
SEEDS = [0, 42, 123, 2024, 31415]
PANEL = ['COX6B2', 'DNAH1', 'GAPDHS', 'REC8']

deg = pd.read_csv(os.path.join(BASE, 'data', 'GSE45885_DEGs_reproduced.csv'))
expr = pd.read_csv(os.path.join(BASE, 'data', 'GSE45885_expression_by_gene_gemma.csv'), index_col=0)
inter389 = set(x.strip() for x in open(os.path.join(BASE, 'results', 'intersection389_gene_list.txt')))
deg_sig_p = set(deg.loc[deg['p_value'] < 0.05, 'GeneSymbol'])
cand = sorted(inter389 & deg_sig_p & set(expr.index))
Xall = expr.loc[cand].T
y = np.array([0] * 4 + [1] * 27)
Xp = Xall[PANEL].values
print(f'X_panel: {Xp.shape}, NOA {y.sum()} / control {len(y)-y.sum()}')

out = {}
for name, clf_fn in [('LogisticRegression', lambda s: LogisticRegression(max_iter=5000, random_state=s)),
                     ('RandomForest', lambda s: RandomForestClassifier(n_estimators=1000, max_depth=5, random_state=s))]:
    accs, bas, aucs = [], [], []
    for s in SEEDS:
        cv = StratifiedKFold(5, shuffle=True, random_state=s)
        clf = clf_fn(s)
        acc = cross_val_score(clf, Xp, y, cv=cv, scoring='accuracy')
        accs.append(acc.mean())
        pred = cross_val_predict(clf, Xp, y, cv=cv)
        bas.append(balanced_accuracy_score(y, pred))
        if hasattr(clf, 'predict_proba'):
            prob = cross_val_predict(clf_fn(s), Xp, y, cv=cv, method='predict_proba')[:, 1]
            aucs.append(roc_auc_score(y, prob))
    out[name] = {'acc_mean': float(np.mean(accs)), 'acc_sd': float(np.std(accs)),
                 'bal_acc_mean': float(np.mean(bas)), 'bal_acc_sd': float(np.std(bas)),
                 'auc_mean': float(np.mean(aucs)) if aucs else None,
                 'auc_sd': float(np.std(aucs)) if aucs else None,
                 'per_seed_acc': [round(a, 3) for a in accs]}
    print(f"{name}: acc {np.mean(accs):.3f}±{np.std(accs):.3f} | bal-acc {np.mean(bas):.3f}±{np.std(bas):.3f} | AUC {np.mean(aucs):.3f}±{np.std(aucs):.3f}" if aucs else f"{name}: acc {np.mean(accs):.3f}±{np.std(accs):.3f} | bal-acc {np.mean(bas):.3f}±{np.std(bas):.3f}")

print(f'\nMajority-class baseline: {27/31:.3f}')
out['baseline'] = 27 / 31
json.dump(out, open(os.path.join(RES, 'cv_panel4_real.json'), 'w'), indent=1)
print('saved -> cv_panel4_real.json')

# 同时产出 S7 逐基因频率表数据 (140 候选 × LASSO/RF/both 5-seed 频率)
j = json.load(open(os.path.join(RES, 'ml_routeA_frozen.json')))
from collections import Counter
lasso_freq, rf_freq = Counter(), Counter()
for seed, d in j['panels_by_seed'].items():
    for g in d['lasso']: lasso_freq[g] += 1
    for g in d['rf']: rf_freq[g] += 1
rows = []
for g in j['candidates']:
    rows.append({'Gene': g, 'LASSO_seeds': lasso_freq.get(g, 0), 'RF_seeds': rf_freq.get(g, 0),
                 'LASSO_and_RF_seeds': j['both_freq'].get(g, 0)})
df = pd.DataFrame(rows).sort_values(['LASSO_and_RF_seeds', 'LASSO_seeds', 'RF_seeds'], ascending=False)
df.to_csv(os.path.join(RES, 'S7c_140candidate_seed_frequencies.csv'), index=False)
print(f'S7c freq table: {len(df)} rows, top8:')
print(df.head(8).to_string(index=False))
