#!/usr/bin/env python3
"""
Step 10 (v2, full-file edition): GSE287960 medaka DEG — FULL FILE rerun
=========================================================================
替换原脚本10。差异:
  1. 下载后先校验 gzip 完整性 + 统计总行数, 拒绝截断文件 (原存档为截断的
     4,611 基因版; 官方完整文件 22,941 行, 含 14,683 个唯一基因名字符串,
     其中 7,949 行符号为 NA)
  2. 基因去重仍按大小写不敏感保留首个 (与原分析一致, 复现 osbp2 取
     大写低表达行的行为), 但在全量文件上执行
  3. 输出: 全量 DEG 表 + 389 交集匹配表 + 8 biomarker 直系同源表

最终口径 (v3.4/r8, 与稿件及补充表 S3 一致):
  - Methods 2.8 / Results 3.6: 源矩阵 22,941 行, 其中 7,949 行无基因符号 (NA);
    大小写不敏感去重后 14,472 个唯一符号, 剔除两组计数全零的 1 个基因 (U6),
    实际分析 14,471 个基因
  - 交付表 TableS3_medaka_DEG_recalculated.csv 即本脚本输出 (14,471 行;
    列: gene, log2FC, p_value, FDR, significant, note), 与补充表 S3 逐格一致
  - Results 3.6: 交集匹配 225 个可测基因, nominal p<0.05 命中 1 个 (map3k5, +0.598, p=0.016);
    无交集基因通过 FDR 校正 — 报道为明确阴性结果
  - Table 5: 四基因 panel 仅 COX6B2 方向一致 (n.s.); OSBP2 一致, ACE/CXXC1 不一致
"""
import gzip
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
DIR = REPO_ROOT / "results"
DATA = REPO_ROOT / "data"
P_MATCH = 0.05
MIN_ROWS = 20000          # 完整文件下限 (截断版只有 ~9600 行)
EXPECT_UNIQUE = 14683     # 官方完整文件唯一基因名字符串数 (含 NA 行; 2026-08 版)


def read_tsv_gz_verified(path: Path):
    """完整读取并校验; 截断直接报错退出, 不再静默容错。"""
    raw = gzip.open(path, "rb").read()          # 截断文件在此抛 EOFError
    text = raw.decode("utf-8", errors="ignore")
    lines = [l for l in text.split("\n") if l]
    header = lines[0].rstrip("\r").split("\t")
    rows = [l.split("\t") for l in lines[1:] if len(l.split("\t")) == len(header)]
    if len(rows) < MIN_ROWS:
        raise RuntimeError(
            f"文件疑似截断: 只有 {len(rows)} 行 (预期 ≥{MIN_ROWS}). "
            f"请重新下载 GSE287960_testis_normExpr_DESeq2.tsv.gz 并核对大小 (~2.2MB)")
    return header, rows


def main():
    header, rows = read_tsv_gz_verified(DATA / "GSE287960_testis_normExpr_DESeq2.tsv.gz")
    samples = header[2:]
    df = pd.DataFrame(rows)
    df["ENSEMBL"] = df[0]
    df["gene_name"] = df[1].astype(str)
    print(f"读取 {len(df)} 行 | 唯一基因名 {df['gene_name'].nunique()}")

    controls = [c for c in samples if c.endswith("1A") or c.endswith("1B") or c.endswith("1C")]   # 后缀A = 0 mg/L
    pfos = [c for c in samples if c.endswith("2A") or c.endswith("2B") or c.endswith("2C") or c.endswith("3A") or c.endswith("3B") or c.endswith("3C")]   # dose 2/3 (0.002/0.02 mg/L), both lineages
    ctrl_idx = [samples.index(c) for c in controls]
    pfos_idx = [samples.index(c) for c in pfos]
    print(f"control n={len(controls)}, PFOS n={len(pfos)}")

    # 大小写不敏感去重保留首个 (与原分析一致)
    df["glower"] = df["gene_name"].str.lower()
    sub = df[~df["glower"].duplicated(keep="first")].copy()

    vals = sub[list(range(2, 2 + len(samples)))].astype(float).values
    C, P = vals[:, ctrl_idx], vals[:, pfos_idx]
    keep = ~(np.all(C == 0, axis=1) & np.all(P == 0, axis=1))
    sub, C, P = sub[keep], C[keep], P[keep]
    print(f"分析基因数: {len(sub)}")

    t, pv = stats.ttest_ind(P, C, axis=1, equal_var=False)
    with np.errstate(divide="ignore", invalid="ignore"):
        lfc = np.where(C.mean(axis=1) > 0,
                       np.log2(P.mean(axis=1) / C.mean(axis=1)), np.nan)

    res = pd.DataFrame({"gene": sub["gene_name"].values,
                        "log2FC": lfc, "p_value": pv})
    _, fdr, _, _ = multipletests(res["p_value"].fillna(1), method="fdr_bh")
    res["FDR"] = fdr
    res["significant"] = res["p_value"] < P_MATCH
    res["note"] = np.where(res["log2FC"].isna(),
                           "log2FC undefined (zero normalized counts in one group)", "")
    res.loc[res["gene"].str.upper() == "NA", "note"] = (
        "symbol absent in the source annotation (7,949 rows share this placeholder symbol)")
    print(f"输出基因数: {len(res)} | 名义 p<{P_MATCH}: {int(res['significant'].sum())} | "
          f"FDR<{P_MATCH}: {int((res['FDR'] < P_MATCH).sum())}")
    res.to_csv(DIR / "TableS3_medaka_DEG_recalculated.csv", index=False)

    # 389 交集匹配
    inter = pd.read_csv(DIR / "intersection389_gene_list.txt", header=None, names=["GeneSymbol"])
    m = res[res["gene"].str.lower().isin(inter["GeneSymbol"].str.lower())]
    sig = m[m["p_value"] < P_MATCH]
    sig.to_csv(DIR / "TableS3_medaka_DEG_matched.csv", index=False)
    print(f"交集匹配: {len(m)} | 名义 p<{P_MATCH}: {len(sig)} → {sorted(sig['gene'])}")

    # 8 biomarker 直系同源
    biomarkers = ["FUS", "REC8", "CXXC1", "PARK7", "ACE", "KIRREL3", "NOS1", "OSBP2"]
    rl = res.set_index(res["gene"].str.lower())
    print("\n8 biomarkers (full file):")
    for b in biomarkers:
        if b.lower() in rl.index:
            r = rl.loc[b.lower()]
            if isinstance(r, pd.DataFrame):
                r = r.iloc[0]
            print(f"  {b:8s} l2fc={r['log2FC']:+.3f} p={r['p_value']:.4f}")
        else:
            print(f"  {b:8s} no ortholog")


if __name__ == "__main__":
    main()
