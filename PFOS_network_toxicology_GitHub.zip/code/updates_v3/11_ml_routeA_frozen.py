# 路线A: 冻结 ML 流水线, 5 种子固定重跑, ≥4/5 共识面板
from pathlib import Path
import pandas as pd
import numpy as np
import os, json
from collections import Counter
from sklearn.linear_model import LassoCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
import warnings
# warnings.filterwarnings('ignore')  # commented out for transparency

BASE = str(Path(__file__).resolve().parent.parent.parent)
RES = os.path.join(BASE, 'results')
DATA = os.path.join(BASE, 'data')
DELIV = str(Path(__file__).resolve().parent.parent)
SUPP = str(Path(__file__).resolve().parent.parent)
SEEDS = [0, 42, 123, 2024, 31415]

# ── 1. 数据 ──
deg = pd.read_csv(os.path.join(DATA, 'GSE45885_DEGs_reproduced.csv'))
expr = pd.read_csv(os.path.join(DATA, 'GSE45885_expression_by_gene_gemma.csv'), index_col=0)
inter389 = set(x.strip() for x in open(os.path.join(RES, 'intersection389_gene_list.txt')))
deg_sig_p = set(deg.loc[deg['p_value'] < 0.05, 'GeneSymbol'])     # 名义 p<0.05 (ML 候选口径)
cand = sorted(inter389 & deg_sig_p & set(expr.index))
print(f'候选: 389 ∩ DEG(p<0.05) ∩ 表达矩阵 = {len(cand)}')

X = expr.loc[cand].T.values
y = np.array([0] * 4 + [1] * 27)
print(f'X: {X.shape}, y: {y.sum()} NOA / {len(y)-y.sum()} control')

# ── 2. 多种子 LASSO + RF ──
lasso_freq, rf_freq, both_freq = Counter(), Counter(), Counter()
panels = {}
for seed in SEEDS:
    lasso = LassoCV(cv=StratifiedKFold(5, shuffle=True, random_state=seed),
                    random_state=seed, max_iter=10000, n_jobs=-1).fit(X, y)
    ls = set(np.array(cand)[lasso.coef_ != 0])
    rf = RandomForestClassifier(n_estimators=1000, max_depth=5,
                                random_state=seed, n_jobs=-1).fit(X, y)
    rs = set(pd.Series(rf.feature_importances_, index=cand)[rf.feature_importances_ > 0.01].index)
    both = ls & rs
    panels[seed] = {'lasso': sorted(ls), 'rf': sorted(rs), 'both': sorted(both)}
    for g in ls: lasso_freq[g] += 1
    for g in rs: rf_freq[g] += 1
    for g in both: both_freq[g] += 1
    print(f'seed {seed}: LASSO {len(ls)} | RF {len(rs)} | ∩ {len(both)}')

print()
print('=== LASSO 各种子入选基因 ===')
for seed in SEEDS:
    print(f'  {seed}: {panels[seed]["lasso"]}')
print()
print('=== 5-seed 频率 (LASSO∩RF) ===')
for g, c in sorted(both_freq.items(), key=lambda x: -x[1]):
    print(f'  {g}: {c}/5')

# ── 3. 共识面板: ≥4/5 ──
panel_4 = sorted([g for g, c in both_freq.items() if c >= 4])
panel_3 = sorted([g for g, c in both_freq.items() if c >= 3])
print()
print(f'=== 共识面板 ===')
print(f'  ≥4/5 ({len(panel_4)}): {panel_4}')
print(f'  ≥3/5 ({len(panel_3)}): {panel_3}')

# ── 4. 保存 ──
out = {'candidates': cand, 'panels_by_seed': panels, 'both_freq': dict(both_freq),
       'panel_ge4': panel_4, 'panel_ge3': panel_3}
json.dump(out, open(os.path.join(RES, 'ml_routeA_frozen.json'), 'w'), indent=1)
print('saved ml_routeA_frozen.json')

# ── 5. 面板基因的 DEG 详情 ──
deg_idx = deg.set_index('GeneSymbol')
print()
print('=== 共识面板基因在复核 DEG 表 (TableS2 口径) ===')
for g in panel_4:
    r = deg_idx.loc[g]
    r = r.iloc[0] if isinstance(r, pd.DataFrame) else r
    print(f'  {g:8s} log2FC={r["log2FC"]:+.3f} p={r["p_value"]:.2e} FDR={r["FDR"]:.2e}')
