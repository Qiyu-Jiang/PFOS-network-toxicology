# Dock consensus panel receptors GAPDHS (O14556) and COX6B2 (Q6YFQ2) with AutoDock Vina
import json, subprocess, os
BASE = os.environ.get('PFOS_DOCK_DIR', './new_panel_docking')
VINA = os.environ.get('VINA_BIN', 'vina')
LIG = os.environ.get('PFOS_LIGAND', 'pfos_ligand.pdbqt')
info = json.load(open(os.path.join(BASE, 'new_panel_info.json')))
results = {}
for gene in ['GAPDHS', 'COX6B2']:
    rec = info[gene]['rec']
    center = info[gene]['center']
    cfg = os.path.join(BASE, f'cfg_{gene}.txt')
    out = os.path.join(BASE, f'out_{gene}.pdbqt')
    with open(cfg, 'w') as f:
        f.write(f'receptor = {rec}\nligand = {LIG}\n')
        f.write(f"center_x = {center[0]}\ncenter_y = {center[1]}\ncenter_z = {center[2]}\n")
        f.write('size_x = 25\nsize_y = 25\nsize_z = 25\n')
        f.write('exhaustiveness = 32\nnum_modes = 5\n')
        f.write(f'out = {out}\n')
    r = subprocess.run([VINA, '--config', cfg, '--verbosity', '1'], capture_output=True, text=True, timeout=3600)
    best = None
    for line in r.stdout.splitlines():
        parts = line.split()
        if len(parts) == 4 and parts[0] == '1':
            try: best = float(parts[1])
            except ValueError: pass
    results[gene] = best
    print(gene, best, flush=True)
json.dump(results, open(os.path.join(BASE, 'docking_results.json'), 'w'), indent=1)
