#!/usr/bin/env python3
"""
Step 14b (新增): FUS-ZnF 位点特异性对接
==========================================
背景: 原稿 FUS 对接因 6G99 的 15,120 原子"数值溢出"而悬置(Pending)。
真相: 6G99 是 NMR 溶液结构, 含 20 个 MODEL 系综 (~756 原子/模型),
原脚本未去重系综导致原子数虚高 20 倍。单模型蛋白仅 596 原子。

本脚本流程:
  1. 下载 6G99, 只取 MODEL 1, 分离蛋白/RNA(UGGUG)/ZN
  2. 受体 = 蛋白链(596 原子, 去除 RNA 与锌), 转 PDBQT
  3. 对接盒子中心 = RNA(UGGUG) 配体几何中心 (-5.96, 15.68, -7.82)
     即 FUS-ZnF 的 RNA 结合口袋 —— 结构实验 (NMR) 定义的生物学位点
  4. PFOS 配体: PubChem CID 74483 3D SDF -> meeko PDBQT (8 可旋转键)
  5. AutoDock Vina 1.2.7, exhaustiveness=32, num_modes=5

结果 (2026-08-27, 4 次独立运行):
  default -7.484 | seed42 -7.431 | seed123 -7.499 | seed2024 -7.436
  mean = -7.46 ± 0.03 kcal/mol  →  Very strong (≤ -7.0)
  建议论文报告: -7.46 (四种子均值) 或 -7.484 (首次运行, 与其他靶点口径一致)

依赖: rdkit meeko (pip install rdkit meeko gemmi) + vina_1.2.7_win.exe
"""
import subprocess, os, re, sys
from pathlib import Path

# ── 配置 ──
BASE = Path(__file__).parent
VINA = BASE / "bin" / "vina.exe"          # vina_1.2.7_win.exe 放此目录
WORK = BASE / "fus_docking"
WORK.mkdir(exist_ok=True)

PDB_URL = "https://files.rcsb.org/download/6G99.pdb"
PFOS_SDF_URL = ("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/"
                "cid/74483/SDF?record_type=3d")

AD_TYPES = {"C": "C", "N": "N", "O": "O", "S": "SA"}


def fetch(url, dest):
    if not dest.exists():
        import requests
        dest.write_bytes(requests.get(url, timeout=120).content)
    return dest


def build_receptor():
    """6G99 -> MODEL 1 蛋白(去 RNA/ZN) -> PDBQT (LF 换行!)"""
    pdb = fetch(PDB_URL, WORK / "6G99.pdb")
    prot, rna = [], []
    in_m1 = False
    for line in pdb.read_text().split("\n"):
        if line.startswith("MODEL"):
            in_m1 = line.split()[1] == "1"
            continue
        if line.startswith("ENDMDL") and in_m1:
            break
        if not in_m1 or not line.startswith("ATOM"):
            continue
        res = line[17:20].strip()
        (rna if res in ("U", "G", "A", "C") else prot).append(line)

    # RNA 中心 = 对接盒子中心
    def center(lines):
        n = len(lines)
        xs = sum(float(l[30:38]) for l in lines) / n
        ys = sum(float(l[38:46]) for l in lines) / n
        zs = sum(float(l[46:54]) for l in lines) / n
        return round(xs, 2), round(ys, 2), round(zs, 2)

    cx, cy, cz = center(rna)
    print(f"receptor: {len(prot)} protein atoms | RNA center = ({cx},{cy},{cz})")

    out = []
    for line in prot:
        elem = line[76:78].strip() or line[12:16].strip()[0]
        out.append(line.rstrip()[:77].ljust(77) + f"{AD_TYPES.get(elem, 'C'):>2s}")
    rec = WORK / "fus_znf_protein.pdbqt"
    rec.write_bytes(("\n".join(out) + "\n").encode("ascii"))   # 必须 LF
    return rec, (cx, cy, cz)


def build_ligand():
    """PFOS 3D SDF -> meeko PDBQT (含 BRANCH 拓扑与 G 电荷)"""
    from meeko import MoleculePreparation, PDBQTWriterLegacy
    from rdkit import Chem
    sdf = fetch(PFOS_SDF_URL, WORK / "PFOS_3d.sdf")
    mol = Chem.SDMolSupplier(str(sdf), removeHs=False)[0]
    result = MoleculePreparation().prepare(mol)
    pdbqt, ok, err = PDBQTWriterLegacy.write_string(result[0])
    if not ok:
        raise RuntimeError(f"meeko failed: {err}")
    lig = WORK / "pfos_ligand.pdbqt"
    lig.write_bytes(pdbqt.replace("\r", "").encode("ascii"))   # 必须 LF
    return lig


def dock(rec, lig, center, seed=None, tag="run"):
    cfg = WORK / f"vina_{tag}.txt"
    cfg.write_text(
        f"receptor = {rec}\nligand = {lig}\n"
        f"center_x = {center[0]}\ncenter_y = {center[1]}\ncenter_z = {center[2]}\n"
        f"size_x = 22\nsize_y = 22\nsize_z = 22\n"
        f"exhaustiveness = 32\nnum_modes = 5\n"
        f"out = {WORK / f'fus_pfos_{tag}.pdbqt'}\n")
    cmd = [str(VINA), "--config", str(cfg), "--verbosity", "1"]
    if seed is not None:
        cmd += ["--seed", str(seed)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    for line in r.stdout.splitlines():
        parts = line.split()
        if len(parts) == 4 and parts[0] == "1":
            return float(parts[1])
    raise RuntimeError(f"docking failed:\n{r.stdout[-500:]}")


def main():
    rec, center = build_receptor()
    lig = build_ligand()

    vals = {}
    vals["default"] = dock(rec, lig, center, seed=None, tag="default")
    for seed in (42, 123, 2024):
        vals[f"seed{seed}"] = dock(rec, lig, center, seed=seed, tag=f"s{seed}")

    print("\n=== FUS-ZnF × PFOS 位点对接结果 ===")
    for k, v in vals.items():
        print(f"  {k:8s}: {v:+.3f} kcal/mol")
    nums = list(vals.values())
    mean = sum(nums) / len(nums)
    print(f"  mean    : {mean:+.3f} kcal/mol  (± {max(nums)-min(nums):.3f} range)")
    print(f"  判定    : {'Very strong (≤-7.0)' if mean <= -7.0 else 'Strong (-5~-7)' if mean <= -5 else 'Weak'}")


if __name__ == "__main__":
    main()
