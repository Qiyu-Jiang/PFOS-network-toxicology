# 新面板基因数据准备: medaka 同源 + UniProt ID + AF 下载 + 对接
import requests, os, json, subprocess, re
from pathlib import Path
import pandas as pd

BASE = str(Path(__file__).resolve().parent.parent.parent)
DELIV = str(Path(__file__).resolve().parent.parent.parent)
VINA = os.path.join(BASE, 'bin', 'vina.exe')
LIG = os.path.join(BASE, 'data', 'docking', 'pfos_ligand.pdbqt')
WORK = os.path.join(BASE, 'new_panel_docking')
os.makedirs(WORK, exist_ok=True)
AD = {'C': 'C', 'N': 'N', 'O': 'O', 'S': 'SA'}

NEW_GENES = ['DNAH1', 'GAPDHS', 'COX6B2', 'REC8']

# ── 1. medaka 同源 ──
med = pd.read_csv(os.path.join(BASE, 'results', 'TableS3_medaka_DEG_recalculated.csv'))
print('=== medaka 同源搜索 ===')
for g in ['rec8', 'dnah1', 'gapdhs', 'cox6b2', 'cox6b']:
    hits = med[med['gene'].astype(str).str.lower().str.startswith(g)]
    if not hits.empty:
        for _, r in hits.iterrows():
            print(f"  {r['gene']} log2FC={r['log2FC']:+.3f} p={r['p_value']:.4f}")
    else:
        print(f"  {g}: 无 medaka 记录")

# ── 2. UniProt ID 反查 ──
def up_search(gene):
    r = requests.get('https://rest.uniprot.org/uniprotkb/search',
                     params={'query': f'gene:{gene} AND organism_id:9606', 'format': 'json', 'size': 2,
                             'fields': 'accession,protein_name'},
                     timeout=60)
    results = r.json().get('results', [])
    out = []
    for e in results:
        desc = e.get('proteinDescription', {})
        name = (desc.get('recommendedName') or desc.get('submissionNames', [{}])[0] if desc.get('submissionNames') else desc.get('recommendedName') or {}).get('fullName', {}).get('value', '?')
        out.append({'acc': e['primaryAccession'], 'name': name[:60]})
    return out

for g in NEW_GENES:
    res = up_search(g)
    print(f'{g} UniProt:', res[:2])

# ── 3. 对接准备 ──
def prep_af(acc, gene):
    pdb = os.path.join(WORK, f'AF-{acc}-F1-model_v6.pdb')
    if not os.path.exists(pdb):
        url = f'https://alphafold.ebi.ac.uk/files/AF-{acc}-F1-model_v6.pdb'
        r = requests.get(url, timeout=180, headers={'User-Agent': 'Mozilla/5.0'})
        r.raise_for_status()
        with open(pdb, 'wb') as f:
            f.write(r.content)
    prot = []
    for line in open(pdb, encoding='utf-8', errors='replace'):
        if line.startswith('ATOM'):
            elem = line[76:78].strip() or line[12:16].strip()[0]
            if elem == 'H':
                continue
            ad = AD.get(elem, 'C')
            prot.append(line.rstrip()[:77].ljust(77) + f'{ad:>2s}')
    out = os.path.join(WORK, f'rec_{gene}.pdbqt')
    with open(out, 'wb') as f:
        f.write(('\n'.join(prot) + '\n').encode('ascii'))
    xs = [float(l[30:38]) for l in prot]
    ys = [float(l[38:46]) for l in prot]
    zs = [float(l[46:54]) for l in prot]
    center = (round(sum(xs)/len(xs), 2), round(sum(ys)/len(ys), 2), round(sum(zs)/len(zs), 2))
    return out, center, len(prot)

results = {}
for gene in NEW_GENES:
    res = up_search(gene)
    acc = res[0]['acc'] if res else None
    if not acc:
        print(f'{gene}: no UniProt entry found')
        continue
    try:
        rec, center, natoms = prep_af(acc, gene)
        print(f'{gene} ({acc}): {natoms} atoms, center={center}')
        results[gene] = {'acc': acc, 'rec': rec, 'center': center}
    except Exception as e:
        print(f'{gene} FAIL: {e}')

# 保存
json.dump(results, open(os.path.join(WORK, 'new_panel_info.json'), 'w'), indent=1)
print('\nresults saved')
