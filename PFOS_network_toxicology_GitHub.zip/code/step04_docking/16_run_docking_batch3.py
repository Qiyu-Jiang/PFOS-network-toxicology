import os, numpy as np
from vina import Vina

rec_dir = "data/docking/receptors"
lig = "data/docking/ligands/PFOS.pdbqt"
results_dir = "data/docking/results"

def get_center(pdbqt):
    coords = []
    with open(pdbqt) as f:
        for line in f:
            if line.startswith('ATOM'):
                try:
                    coords.append([float(line[30:38]),float(line[38:46]),float(line[46:54])])
                except: pass
    c = np.mean(coords, axis=0)
    return [round(float(c[0]),1), round(float(c[1]),1), round(float(c[2]),1)]

def get_size(pdbqt):
    n = 0
    with open(pdbqt) as f:
        for line in f:
            if line.startswith('ATOM'): n += 1
    return n

targets = [('ACE', 'ACE_1O8A.pdbqt'), ('NOS1', 'NOS1_4D1N.pdbqt'), ('FUS', 'FUS_6G99.pdbqt')]

log = open(os.path.join(results_dir, "docking_log2.txt"), "w")
for gene, fname in targets:
    rec = os.path.join(rec_dir, fname)
    n = get_size(rec)
    center = get_center(rec)
    box = [20,20,20] if n > 5000 else [25,25,25]
    log.write(f"{gene} ({n} atoms): center={center}, box={box}\n")
    log.flush()
    
    try:
        v = Vina(sf_name='vina')
        v.set_receptor(rec)
        v.set_ligand_from_file(lig)
        v.compute_vina_maps(center=center, box_size=box)
        v.dock(exhaustiveness=8, n_poses=5)
        energies = v.energies()
        best = energies[0][0]
        v.write_poses(os.path.join(results_dir, f"{gene}_PFOS_docking.pdbqt"), n_poses=5, overwrite=True)
        log.write(f"  Best: {best:.3f} kcal/mol\n")
        for i, e in enumerate(energies[:5]):
            log.write(f"    #{i+1}: {e[0]:.3f} (rmsd={e[1]:.2f},{e[2]:.2f})\n")
        log.flush()
    except Exception as e:
        log.write(f"  ERROR: {e}\n")
        log.flush()

log.write("\nDone!\n")
log.close()
