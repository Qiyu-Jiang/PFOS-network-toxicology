import os, numpy as np
from vina import Vina

rec_dir = "data/docking/receptors"
lig = "data/docking/ligands/PFOS.pdbqt"
results_dir = "data/docking/results"
os.makedirs(results_dir, exist_ok=True)

def get_center(pdbqt):
    coords = []
    with open(pdbqt) as f:
        for line in f:
            if line.startswith('ATOM'):
                try:
                    coords.append([float(line[30:38]),float(line[38:46]),float(line[46:54])])
                except: pass
    c = np.mean(coords, axis=0)
    return [round(float(c[0]),1), round(float(c[1]),1), round(float(c[2]),1)]

def get_size(pdbqt):
    n = 0
    with open(pdbqt) as f:
        for line in f:
            if line.startswith('ATOM'): n += 1
    return n

# 所有PDBQT文件, 按大小排序
receptors = []
for f in os.listdir(rec_dir):
    if f.endswith('.pdbqt'):
        gene = f.split('_')[0]
        path = os.path.join(rec_dir, f)
        # 跳过已完成的
        out_file = os.path.join(results_dir, f"{gene}_PFOS_docking.pdbqt")
        if os.path.exists(out_file) and os.path.getsize(out_file) > 100:
            continue
        n = get_size(path)
        receptors.append((gene, f, path, n))

receptors.sort(key=lambda x: x[3])  # 按原子数排序

log = open(os.path.join(results_dir, "docking_log.txt"), "w")
log.write(f"待对接: {len(receptors)} 个蛋白\n")
log.write(f"按原子数排序: {[(r[0],r[3]) for r in receptors]}\n\n")
log.flush()

for gene, fname, rec_path, n_atoms in receptors:
    center = get_center(rec_path)
    log.write(f"{gene} ({n_atoms} atoms): center={center}\n")
    log.flush()
    
    try:
        v = Vina(sf_name='vina')
        v.set_receptor(rec_path)
        v.set_ligand_from_file(lig)
        # 大蛋白用小box, 小蛋白用大box
        box = [20,20,20] if n_atoms > 5000 else [25,25,25]
        v.compute_vina_maps(center=center, box_size=box)
        v.dock(exhaustiveness=8, n_poses=5)
        
        energies = v.energies()
        best = energies[0][0]
        
        v.write_poses(os.path.join(results_dir, f"{gene}_PFOS_docking.pdbqt"), n_poses=5, overwrite=True)
        
        log.write(f"  Best: {best:.3f} kcal/mol\n")
        for i, e in enumerate(energies[:5]):
            log.write(f"    #{i+1}: {e[0]:.3f} (rmsd={e[1]:.2f},{e[2]:.2f})\n")
        log.flush()
    except Exception as e:
        log.write(f"  ERROR: {e}\n")
        log.flush()

log.write("\nDone!\n")
log.close()
