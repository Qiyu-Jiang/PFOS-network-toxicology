import os, json, numpy as np
from vina import Vina
import pandas as pd

receptor_dir = "data/docking/receptors"
ligand_file = "data/docking/ligands/PFOS.pdbqt"
results_dir = "data/docking/results"
os.makedirs(results_dir, exist_ok=True)

receptors = sorted([f for f in os.listdir(receptor_dir) if f.endswith('.pdbqt')])

def get_center(pdbqt_file):
    coords = []
    with open(pdbqt_file) as f:
        for line in f:
            if line.startswith('ATOM') or line.startswith('HETATM'):
                try:
                    x, y, z = float(line[30:38]), float(line[38:46]), float(line[46:54])
                    coords.append([x, y, z])
                except:
                    pass
    coords = np.array(coords)
    center = coords.mean(axis=0)
    return [round(float(center[0]), 1), round(float(center[1]), 1), round(float(center[2]), 1)]

results = []
log_lines = []

for rec_file in receptors:
    gene = rec_file.split('_')[0]
    rec_path = os.path.join(receptor_dir, rec_file)
    center = get_center(rec_path)
    box_size = [25, 25, 25]
    
    log_lines.append(f"\n{gene}: center={center}")
    
    try:
        v = Vina(sf_name='vina')
        v.set_receptor(rec_path)
        v.set_ligand_from_file(ligand_file)
        v.compute_vina_maps(center=center, box_size=box_size)
        v.dock(exhaustiveness=32, n_poses=10, min_rmsd=2.0)
        
        out_pdbqt = os.path.join(results_dir, f"{gene}_PFOS_docking.pdbqt")
        v.write_poses(out_pdbqt, n_poses=5, overwrite=True)
        
        energies = v.energies()
        best = energies[0][0] if len(energies) > 0 else None
        log_lines.append(f"  Best: {best:.3f} kcal/mol")
        for i, e in enumerate(energies[:5]):
            log_lines.append(f"    #{i+1}: {e[0]:.3f} kcal/mol (rmsd={e[1]:.2f},{e[2]:.2f})")
        
        results.append({'Gene': gene, 'Best_affinity': round(best, 3), 'Center': str(center)})
    except Exception as e:
        log_lines.append(f"  ERROR: {e}")
        results.append({'Gene': gene, 'Best_affinity': None, 'Center': str(center)})

# 保存
with open(os.path.join(results_dir, "docking_log.txt"), 'w') as f:
    f.write('\n'.join(log_lines))

df = pd.DataFrame(results).sort_values('Best_affinity')
df.to_csv(os.path.join(results_dir, "docking_summary.csv"), index=False)

with open(os.path.join(results_dir, "docking_done.txt"), 'w') as f:
    f.write(f"Done! {len(results)} dockings\n")
    for _, r in df.iterrows():
        f.write(f"{r['Gene']}: {r['Best_affinity']}\n")
