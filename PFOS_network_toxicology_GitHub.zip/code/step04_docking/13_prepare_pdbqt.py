#!/usr/bin/env python3
"""
Step 13: 受体蛋白结构准备 (PDB/AlphaFold → PDBQT)
===================================================
蛋白来源:
  实验结构(RCSB PDB, 优先):
    FUS: 6G99    PARK7: 1P5F    ACE: 1O8A    NOS1: 4D1N
  AlphaFold模型(无合适PDB的靶点):
    CXXC1 (Q9P0L0)  KIRREL3 (Q8N3S9)  OSBP2 (Q9BXW6)  REC8 (O95032)

处理流程:
  1. 下载PDB/AlphaFold文件(已有则跳过)
  2. 去除水分子(HOH)与全部HETATM金属离子
     ⚠ 金属(ZN/FE/MG/CA/MN/CU/NA/K)在PDBQT中类型为"Z"会导致Vina报错
  3. 标准氨基酸残基 → PDBQT格式(末列加AutoDock原子类型)
  4. 配体PFOS: SDF→PDBQT (meeko prepare_ligand)

输出:  data_analysis/docking/receptors/*.pdbqt
       data_analysis/docking/ligands/PFOS.pdbqt

依赖: requests meeko rdkit (pip install meeko rdkit gemmi)
"""
import os
import requests
from pathlib import Path

DOCK = Path("data/docking")
REC = DOCK / "receptors"
LIG = DOCK / "ligands"
REC.mkdir(parents=True, exist_ok=True)
LIG.mkdir(parents=True, exist_ok=True)

# 靶点 → (文件名, 来源)
TARGETS = {
    "FUS":     ("FUS_6G99.pdb",    "pdb:6G99"),
    "PARK7":   ("PARK7_1P5F.pdb",  "pdb:1P5F"),
    "ACE":     ("ACE_1O8A.pdb",    "pdb:1O8A"),
    "NOS1":    ("NOS1_4D1N.pdb",   "pdb:4D1N"),
    "CXXC1":   ("CXXC1_AF.pdb",    "af:Q9P0L0"),
    "KIRREL3": ("KIRREL3_AF.pdb",  "af:Q8N3S9"),
    "OSBP2":   ("OSBP2_AF.pdb",    "af:Q9BXW6"),
    "REC8":    ("REC8_AF.pdb",     "af:O95032"),
}

# 必须去除的金属离子
METALS = {"ZN", "FE", "MG", "CA", "MN", "CU", "NA", "K", "FE2", "MN3"}

# 元素 → AutoDock原子类型
AD_TYPES = {"C": "C", "N": "N", "O": "O", "S": "SA"}


def download(name, source):
    out = REC / name
    if out.exists():
        return out
    if source.startswith("pdb:"):
        pdb_id = source[4:]
        url = f"https://files.rcsb.org/download/{pdb_id}.pdb"
    else:  # AlphaFold
        uid = source[3:]
        url = f"https://alphafold.ebi.ac.uk/files/AF-{uid}-F1-model_v6.pdb"
    r = requests.get(url, timeout=120,
                     headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    out.write_text(r.text)
    print(f"  下载 {name} ← {url}")
    return out


def pdb_to_pdbqt(pdb_path, pdbqt_path):
    """PDB→PDBQT: 去水/金属/非标准残基, 末列写AutoDock类型。"""
    kept, removed = 0, 0
    with open(pdb_path) as fin, open(pdbqt_path, "w") as fout:
        for line in fin:
            if line.startswith(("ATOM", "TER", "END")):
                if line.startswith("ATOM"):
                    res = line[17:20].strip()
                    if res == "HOH":
                        removed += 1
                        continue
                    elem = line[76:78].strip()
                    ad = AD_TYPES.get(elem, "C")
                    # 末列写AutoDock原子类型(占位到78-79列)
                    out = line.rstrip("\n")
                    out = out[:77].ljust(77) + f"{ad:>2s}\n"
                    fout.write(out)
                    kept += 1
                else:
                    fout.write(line)
            elif line.startswith("HETATM"):
                res = line[17:20].strip()
                if res in METALS or res == "HOH":
                    removed += 1
    print(f"  {pdbqt_path.name}: 保留{kept}原子, 去除{removed}个水/金属")
    return kept


def prepare_ligand():
    """PFOS: SDF → PDBQT (meeko)。SMILES来源PubChem CID 74483。"""
    out = LIG / "PFOS.pdbqt"
    if out.exists():
        return
    sdf = LIG / "PFOS.sdf"
    if not sdf.exists():
        r = requests.get(
            "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/"
            "cid/74483/record/SDF?record_type=3d",
            timeout=120, headers={"User-Agent": "Mozilla/5.0"})
        sdf.write_text(r.text)
    from meeko import PDBQTWriterLegacy, MoleculePreparation
    from rdkit import Chem
    mol = Chem.SDMolSupplier(str(sdf), removeHs=False)[0]
    prep = MoleculePreparation()
    result = prep.prepare(mol)
    pdbqt, ok, err = PDBQTWriterLegacy.write_string(result[0])
    out.write_text(pdbqt)
    print(f"  配体PFOS.pdbqt已生成 ({len(pdbqt)}字节)")


def main():
    print("── 受体准备 ──")
    for gene, (name, source) in TARGETS.items():
        print(f"[{gene}]")
        pdb = download(name, source)
        pdbqt = pdb.with_suffix(".pdbqt")
        if pdbqt.exists():
            print(f"  {pdbqt.name}已存在, 跳过")
            continue
        n = pdb_to_pdbqt(pdb, pdbqt)
        if n == 0:
            print(f"  ⚠ {gene}转换后无原子!")

    print("── 配体准备 ──")
    prepare_ligand()
    print("\n完成。⚠ 注意: FUS(6G99)有15,100原子, 盲对接会数值溢出,")
    print("论文中FUS无对接结果(Discussion已说明); 其余7个靶点正常对接。")


if __name__ == "__main__":
    main()
