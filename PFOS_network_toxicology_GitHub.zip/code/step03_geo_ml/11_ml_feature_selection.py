#!/usr/bin/env python3
"""
Step 11: 机器学习筛选核心生物标志物 (LASSO + Random Forest)
=============================================================
输入:  114 ML候选基因 × 31样本表达矩阵 (379交集 ∩ p<0.05的NOA DEG)
模型:
  - LASSO: LassoCV, 5折分层CV自动选alpha(本数据alpha≈0.041), 未设random_state
    → 非零系数基因 n=10
  - RF: RandomForestClassifier(n_estimators=1000, max_depth=5),
    5折分层CV, 未设random_state → importance > 0.01 的基因 n=37
  - 最终标志物 = LASSO ∩ RF → 8个:
    FUS, REC8, CXXC1, PARK7, ACE, KIRREL3, NOS1, OSBP2

输出:  data_analysis/ml_lasso_selected.csv
       data_analysis/ml_rf_selected.csv
       data_analysis/ml_final_biomarkers.csv
       data_analysis/ml_feature_selection.png

⚠ 稳定性警示(2026-08-08 QC):
  小样本(4 control vs 27 NOA)下LassoCV的alpha选择对CV随机划分敏感。
  5个seed(0/42/123/2024/31415)重跑显示仅REC8在LASSO∩RF中5/5稳定出现
  (另发现DNAH1、GAPDHS两个5/5稳定基因未纳入原始panel)。详见
  step06_qc/21_qc_ml_stability.py。论文Discussion局限部分已声明。

依赖: pandas scikit-learn matplotlib
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.linear_model import LassoCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from pathlib import Path

BASE = Path("data")
RF_IMPORTANCE_CUTOFF = 0.01
N_ESTIMATORS = 1000
MAX_DEPTH = 5


def build_candidates():
    """构建ML候选表达矩阵(如已存在则直接读取)。
    逻辑: 379交集 ∩ NOA DEG(p<0.05) → 按基因取均值。"""
    cached = BASE / "ml_candidate_expression.csv"
    if cached.exists():
        return pd.read_csv(cached, index_col=0)

    inter = pd.read_csv(BASE / "pfos_disease_intersection.csv")
    deg = pd.read_csv(BASE / "geo/GSE45885_DEGs_NOA_vs_control.csv")
    expr = pd.read_csv(BASE / "geo/GSE45885_expression_by_gene.csv",
                       index_col=0)

    sig = deg[deg["p_value"] < 0.05]
    cand = set(inter["GeneSymbol"]) & set(sig["GeneSymbol"])
    sub = expr.loc[expr.index.isin(cand)]
    sub.to_csv(cached)
    genes_df = sig[sig["GeneSymbol"].isin(cand)][
        ["GeneSymbol", "log2FC", "p_value", "FDR", "direction"]]
    genes_df.to_csv(BASE / "ml_candidate_genes.csv", index=False)
    print(f"ML候选: {sub.shape[0]}基因 × {sub.shape[1]}样本")
    return sub


def run_lasso(X, y, genes):
    cv = StratifiedKFold(n_splits=5, shuffle=True)
    lasso = LassoCV(cv=cv, n_jobs=-1).fit(X, y)
    print(f"LASSO最优alpha: {lasso.alpha_:.4f}")
    coef = pd.Series(lasso.coef_, index=genes)
    selected = coef[coef != 0].sort_values(key=abs, ascending=False)
    selected.to_csv(BASE / "ml_lasso_selected.csv")
    print(f"LASSO非零系数: {len(selected)}基因")
    return selected


def run_rf(X, y, genes):
    cv = StratifiedKFold(n_splits=5, shuffle=True)
    rf = RandomForestClassifier(n_estimators=N_ESTIMATORS,
                                max_depth=MAX_DEPTH, n_jobs=-1)
    rf.fit(X, y)
    accs = []
    for tr, te in cv.split(X, y):
        rf_ = RandomForestClassifier(n_estimators=N_ESTIMATORS,
                                     max_depth=MAX_DEPTH, n_jobs=-1)
        rf_.fit(X[tr], y[tr])
        accs.append(rf_.score(X[te], y[te]))
    print(f"RF 5折CV准确率: {np.mean(accs):.3f} ± {np.std(accs):.3f}")
    imp = pd.Series(rf.feature_importances_, index=genes)
    selected = imp[imp > RF_IMPORTANCE_CUTOFF].sort_values(ascending=False)
    selected.to_csv(BASE / "ml_rf_selected.csv")
    print(f"RF importance>{RF_IMPORTANCE_CUTOFF}: {len(selected)}基因")
    return selected


def main():
    expr = build_candidates()
    genes = expr.index.tolist()
    X = expr.T.values          # samples × genes
    y = np.array([0] * 4 + [1] * 27)   # 前4列control, 后27列NOA

    lasso_sel = run_lasso(X, y, genes)
    rf_sel = run_rf(X, y, genes)

    final = sorted(set(lasso_sel.index) & set(rf_sel.index))
    print(f"\nLASSO ∩ RF = {len(final)}个标志物: {', '.join(final)}")

    # ── 汇总表 ──
    inter = pd.read_csv(BASE / "pfos_disease_intersection.csv")
    deg = pd.read_csv(BASE / "geo/GSE45885_DEGs_NOA_vs_control.csv")
    i_idx = inter.set_index("GeneSymbol")
    d_idx = deg.set_index("GeneSymbol")
    rows = []
    for g in final:
        rows.append({
            "GeneSymbol": g,
            "LASSO_coef": lasso_sel.get(g, 0),
            "RF_importance": rf_sel.get(g, 0),
            "direction": d_idx.loc[g, "direction"],
            "disease_sources": i_idx.loc[g, "disease_sources"],
            "CTD_interaction_count": i_idx.loc[g, "CTD_interaction_count"],
            "DEG_log2FC": d_idx.loc[g, "log2FC"],
            "DEG_pvalue": d_idx.loc[g, "p_value"],
        })
    pd.DataFrame(rows).to_csv(BASE / "ml_final_biomarkers.csv", index=False)

    # ── 图: LASSO系数 + RF重要性 ──
    plt.rcParams.update({"font.size": 8, "savefig.dpi": 300,
                         "savefig.bbox": "tight"})
    fig, axes = plt.subplots(1, 2, figsize=(6.69, 3))
    lasso_sel[::-1].plot.barh(ax=axes[0], color="#3B82F6")
    axes[0].set_title("LASSO coefficients")
    axes[0].set_xlabel("Coefficient")
    rf_sel.head(15)[::-1].plot.barh(ax=axes[1], color="#D97706")
    axes[1].set_title("RF importance (top 15)")
    axes[1].set_xlabel("Importance")
    fig.tight_layout()
    fig.savefig(BASE / "ml_feature_selection.png")
    plt.close(fig)
    print(f"已保存 → ml_final_biomarkers.csv / ml_feature_selection.png")


if __name__ == "__main__":
    main()
