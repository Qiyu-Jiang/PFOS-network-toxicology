#!/usr/bin/env python3
"""
Step 09: GSE45885差异表达分析 (NOA vs Control)
=================================================
数据: 人睾丸活检芯片(Affy GPL6244), 31样本 = 4 control + 27 NOA
      表达值已为log2(RMA)尺度。
统计: 每基因双侧Welch t检验 + Benjamini-Hochberg FDR
      log2FC = mean(NOA) - mean(control)     ← 对log2尺度数据直接作差
      significant: FDR < 0.05 且 |log2FC| ≥ 0.5
      ML候选(下游): p < 0.05 (名义p值, 不设FC阈值)

⚠ 历史bug修正记录 (2026-08-27 QC发现):
  原始分析(2026-07-25)对已是log2尺度的组均值又取了一次log2:
      log2FC_buggy = log2(mean_NOA) - log2(mean_control)
  导致log2FC幅度被压缩约4倍(如REC8: -0.309 vs 真实-1.319),
  显著DEG数从939被低估为81。p值、方向、ML筛选均不受影响(log2单调)。
  本脚本已按正确公式计算。2026-08-27起所有稿件数字基于修正值。

输入:  data_analysis/geo/GSE45885_expression_by_gene.csv  (19427×31)
       data_analysis/geo/GSE45885_sample_info.txt
输出:  data_analysis/geo/GSE45885_DEGs_NOA_vs_control.csv

依赖: pandas scipy statsmodels
"""
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
from pathlib import Path

GEO = Path("data/geo")
LOG2FC_CUTOFF = 0.5
FDR_CUTOFF = 0.05
P_CANDIDATE = 0.05   # ML候选阈值(名义p)


def main():
    expr = pd.read_csv(GEO / "GSE45885_expression_by_gene.csv", index_col=0)
    # 分组: 前4列为control, 其余27列为NOA (见sample_info)
    controls = expr.columns[:4]
    noa = expr.columns[4:]
    print(f"表达矩阵: {expr.shape[0]}基因 × {expr.shape[1]}样本")
    print(f"control n={len(controls)}, NOA n={len(noa)}")

    genes, lfc, pvals, mc, mn = [], [], [], [], []
    for gene, row in expr.iterrows():
        c = row[controls].values.astype(float)
        n = row[noa].values.astype(float)
        t, p = stats.ttest_ind(n, c, equal_var=False)  # Welch
        genes.append(gene)
        lfc.append(n.mean() - c.mean())
        pvals.append(p)
        mc.append(c.mean())
        mn.append(n.mean())

    res = pd.DataFrame({
        "GeneSymbol": genes,
        "log2FC": lfc,
        "p_value": pvals,
        "mean_control": mc,
        "mean_NOA": mn,
    })
    # BH FDR
    reject, fdr, _, _ = multipletests(res["p_value"], method="fdr_bh")
    res["FDR"] = fdr
    res["significant"] = (res["FDR"] < FDR_CUTOFF) & \
                         (res["log2FC"].abs() >= LOG2FC_CUTOFF)
    res["direction"] = np.where(res["log2FC"] > 0, "up", "down")

    res.to_csv(GEO / "GSE45885_DEGs_NOA_vs_control.csv", index=False)
    print(f"\n已保存 → {GEO / 'GSE45885_DEGs_NOA_vs_control.csv'}")
    print(f"显著DEG (FDR<0.05 & |log2FC|≥{LOG2FC_CUTOFF}): "
          f"{res['significant'].sum()}")
    print(f"  up: {((res['significant']) & (res['direction']=='up')).sum()}, "
          f"down: {((res['significant']) & (res['direction']=='down')).sum()}")

    # ML候选 = 交集 ∩ p<0.05
    inter = pd.read_csv("data/"
                        "pfos_disease_intersection.csv")
    cand = set(res.loc[res["p_value"] < P_CANDIDATE, "GeneSymbol"])
    ml_candidates = set(inter["GeneSymbol"]) & cand
    print(f"ML候选 (379交集 ∩ p<{P_CANDIDATE}): {len(ml_candidates)}")


if __name__ == "__main__":
    main()
