#!/usr/bin/env bash
# ============================================================
# Step 07: GEO原始数据下载
# ============================================================
# 数据集:
#   GSE45885  - 人NOA(non-obstructive azoospermia)睾丸组织, Affy GPL6244
#               31样本 (4 control + 27 NOA)
#   GSE287960 - 青鳉鱼PFOS暴露睾丸转录组, 18样本
#               (6 control + 6 PFOS低剂量0.002 + 6 PFOS高剂量0.02 mg/L)
#
# 说明: RNA-seq/部分芯片的series matrix可能不含表达数据，
#       GSE287960需下载supplementary文件(normExpr.tsv.gz)。
#       NCBI FTP偶尔403，加User-Agent；大文件用curl后台断点续传。
# ============================================================
set -e
mkdir -p ./data_analysis/geo/pfos_validation
cd ./data_analysis/geo

UA="Mozilla/5.0"

# ── GSE45885: series matrix (含表达矩阵+样本注释) ──
curl -sL -A "$UA" -o GSE45885_series_matrix.txt.gz \
  "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE45nnn/GSE45885/matrix/GSE45885_series_matrix.txt.gz"

# ── GSE45885: 平台注释 (GPL6244, 探针→基因映射备用) ──
curl -sL -A "$UA" -o GPL6244_family.soft.gz \
  "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL6244nnn/GPL6244/soft/GPL6244_family.soft.gz"

# ── GSE287960: supplementary表达矩阵 (series matrix无表达数据) ──
cd pfos_validation
curl -sL -A "$UA" -o GSE287960_matrix.txt.gz \
  "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE287nnn/GSE287960/matrix/GSE287960_series_matrix.txt.gz"
curl -sL -A "$UA" -o GSE287960_normExpr.tsv.gz \
  "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE287nnn/GSE287960/suppl/GSE287960_normExpr.tsv.gz"

echo "下载完成。注意: tsv.gz若下载不完整(gzip EOFError)，用gzip.open逐行读取可处理截断。"
