import mygene, pandas as pd, time, sys

mg = mygene.MyGeneInfo()
expr = pd.read_csv("data/geo/GSE45885_expression_matrix.csv", index_col=0)
probe_ids = list(expr.index)

BATCH = 500
all_mapped = []
for i in range(0, len(probe_ids), BATCH):
    batch = probe_ids[i:i+BATCH]
    try:
        results = mg.querymany(batch, scopes='affy_hugene10sttranscriptcluster,reporter,entrezgene',
                               fields='symbol', species='human', returnall=False)
        mapped = [(r.get('query'), r.get('symbol')) for r in results if r.get('symbol')]
        all_mapped.extend(mapped)
    except Exception as e:
        with open("data/geo/mapping_progress.txt","a") as f:
            f.write(f"Batch {i}: {e}\n")
    time.sleep(0.2)

df_map = pd.DataFrame(all_mapped, columns=['ProbeID','GeneSymbol'])
df_map = df_map.dropna(subset=['GeneSymbol'])
df_map = df_map[df_map['GeneSymbol'] != 'None']
df_map = df_map.drop_duplicates()
df_map.to_csv("data/geo/GPL6244_probe_gene_mapping.csv", index=False)

# 映射表达矩阵
expr['GeneSymbol'] = expr.index.map(dict(zip(df_map['ProbeID'], df_map['GeneSymbol'])))
mapped_expr = expr[expr['GeneSymbol'].notna()]
expr_genes = mapped_expr.groupby('GeneSymbol').mean(numeric_only=True)
expr_genes.to_csv("data/geo/GSE45885_expression_by_gene.csv")

with open("data/geo/mapping_done.txt","w") as f:
    f.write(f"Mapped: {len(df_map)}/{len(probe_ids)}\n")
    f.write(f"Genes: {len(expr_genes)}\n")
    f.write(f"Shape: {expr_genes.shape}\n")
