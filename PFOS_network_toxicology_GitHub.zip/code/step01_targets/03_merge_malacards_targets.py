"""
MalaCards疾病靶点整合脚本
功能：读取4个MalaCards导出的CSV文件，提取基因Symbol，合并去重，输出疾病靶点全集
作者：生信助手
"""

import pandas as pd
import os
import glob

# ============ 配置 ============
# 文件所在目录（改成你自己的路径）
INPUT_DIR = r"F:\网络毒理学与机器学习\genecards"
OUTPUT_DIR = r"F:\网络毒理学与机器学习\genecards"

# ============ Step 1: 读取所有MalaCards CSV文件 ============
print("=" * 60)
print("Step 1: 读取MalaCards导出文件")
print("=" * 60)

# 查找所有MalaCards导出的CSV文件
csv_files = glob.glob(os.path.join(INPUT_DIR, "MalaCards*.csv"))
if not csv_files:
    # 也尝试xls/xlsx
    csv_files = glob.glob(os.path.join(INPUT_DIR, "MalaCards*.xls*"))

print(f"找到 {len(csv_files)} 个文件：")
for f in csv_files:
    print(f"  - {os.path.basename(f)}")

# ============ Step 2: 逐个读取并提取基因Symbol ============
print("\n" + "=" * 60)
print("Step 2: 提取基因Symbol")
print("=" * 60)

all_genes = set()
file_summaries = []

for filepath in csv_files:
    fname = os.path.basename(filepath)
    try:
        # MalaCards导出的CSV可能用tab或逗号分隔
        # 先尝试逗号
        df = pd.read_csv(filepath, encoding='utf-8', encoding_errors='ignore')
    except Exception:
        try:
            df = pd.read_csv(filepath, sep='\t', encoding='utf-8', encoding_errors='ignore')
        except Exception:
            try:
                df = pd.read_excel(filepath)
            except Exception as e:
                print(f"  [错误] 无法读取 {fname}: {e}")
                continue

    print(f"\n  文件: {fname}")
    print(f"  行数: {len(df)}")
    print(f"  列名: {list(df.columns)}")

    # 找基因Symbol列（MalaCards导出的列名通常含"Symbol"）
    symbol_col = None
    for col in df.columns:
        if 'symbol' in col.lower():
            symbol_col = col
            break

    if symbol_col is None:
        # 如果没找到Symbol列，第一列通常就是基因名
        symbol_col = df.columns[0]
        print(f"  [警告] 未找到Symbol列，使用第一列: {symbol_col}")
    else:
        print(f"  使用基因列: {symbol_col}")

    # 提取基因名，去空值
    genes = df[symbol_col].dropna().astype(str).str.strip()
    # 去掉可能的注释行（以#开头）
    genes = genes[~genes.str.startswith('#')]
    genes = set(genes.tolist())

    print(f"  提取基因数: {len(genes)}")
    file_summaries.append({
        'file': fname,
        'gene_count': len(genes),
        'genes': genes
    })
    all_genes.update(genes)

# ============ Step 3: 合并去重 ============
print("\n" + "=" * 60)
print("Step 3: 合并去重结果")
print("=" * 60)

print(f"\n各文件基因数：")
for s in file_summaries:
    print(f"  {s['file']}: {s['gene_count']} 个基因")

print(f"\n合并去重后总基因数: {len(all_genes)}")

# ============ Step 4: 保存结果 ============
print("\n" + "=" * 60)
print("Step 4: 保存结果")
print("=" * 60)

# 保存为CSV（单列基因Symbol）
result_df = pd.DataFrame(sorted(all_genes), columns=['GeneSymbol'])
output_path = os.path.join(OUTPUT_DIR, "disease_targets_malacards.csv")
result_df.to_csv(output_path, index=False)
print(f"\n已保存: {output_path}")
print(f"共 {len(result_df)} 个疾病靶点基因")

# ============ 预览 ============
print("\n" + "=" * 60)
print("基因列表预览（前20个）：")
print("=" * 60)
print(result_df.head(20).to_string(index=False))

print("\n✅ MalaCards疾病靶点整合完成！")
print(f"下一步：将 disease_targets_malacards.csv 与CTD、OpenTargets的结果合并")
