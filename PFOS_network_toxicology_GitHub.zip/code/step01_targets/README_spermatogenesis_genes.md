# 生精功能障碍相关基因三库整合脚本 — 使用说明

## 数据源

| 数据库 | 访问方式 | 是否需要注册 |
|--------|----------|-------------|
| DisGeNET | API + 本地TSV | 建议注册（免费），获取更全数据 |
| CTD | 直接下载CSV.GZ | 完全免费，无需注册 |
| OpenTargets | GraphQL API | 完全开放，无需认证 |

## 运行环境

```bash
pip install pandas requests tqdm
```

## 运行

```bash
python fetch_spermatogenesis_genes.py
```

## 输出文件（disease_targets/ 目录下）

| 文件 | 说明 |
|------|------|
| `spermatogenesis_genes_merged.tsv` | 三库并集完整表（含来源标注、来源数量） |
| `spermatogenesis_genes_list.txt` | 纯基因列表，每行一个，方便R/Python读取 |
| `spermatogenesis_genes_high_confidence.tsv` | ≥2个数据库支持的高置信基因表 |
| `spermatogenesis_genes_high_confidence.txt` | 高置信纯基因列表 |
| `disgenet_genes.tsv` | DisGeNET明细 |
| `ctd_genes.tsv` | CTD明细 |
| `opentargets_genes.tsv` | OpenTargets明细 |

## 各数据库获取方式补充

### DisGeNET（推荐手动下载TSV）
1. 注册：https://www.disgenet.org/signup
2. 登录后进入 Downloads 页面
3. 下载 `curated_gene_disease_associations.tsv`
4. 放到 `disease_targets/` 目录下
5. 脚本会自动优先使用本地文件

或者填入API key到脚本中 `DISGENET_API_KEY` 变量。

### CTD
- 脚本自动下载，无需操作
- 文件较大（~200MB压缩包），首次运行需要几分钟
- 下载后缓存在本地，后续运行直接读取

### OpenTargets
- 脚本通过GraphQL API自动查询
- 已预配置7个相关疾病EFO ID
- 如需添加更多疾病ID，编辑 `OPENTARGETS_DISEASE_IDS` 列表
- 查找EFO ID：https://www.ebi.ac.uk/ols/ontologies/efo

## 关键词配置

脚本中 `KEYWORDS` 列表定义了疾病过滤关键词，当前覆盖：
- 不育（infertility, male infertility）
- 生精障碍（spermatogenesis, spermatogenic failure）
- 少精/无精（oligospermia, azoospermia）
- 精子异常（asthenozoospermia, teratozoospermia）
- 睾丸功能（testicular dysfunction, seminiferous）

可根据需要增减。

## 下游分析建议

1. **优先使用高置信基因列表**（≥2库支持）与PFOS靶点取交集
2. 也可以分别用三库基因与PFOS靶点取交集，比较重叠情况
3. 取交集后进入机器学习模块（LASSO/SVM-RFE/RF）筛选核心基因

## 交集示例代码（R）

```r
library(clusterProfiler)
library(org.Hs.eg.db)

# 读取疾病靶点
disease_genes <- readLines("disease_targets/spermatogenesis_genes_high_confidence.txt")

# 读取PFOS靶点（假设已获取）
pfos_genes <- readLines("pfos_targets.txt")  # 你的PFOS靶点文件

# 取交集
intersect_genes <- intersect(disease_genes, pfos_genes)
cat("交集基因数：", length(intersect_genes), "\n")

# 可视化
library(VennDiagram)
venn.diagram(
  x = list(Disease = disease_genes, PFOS = pfos_genes),
  filename = "venn_disease_pfos.png",
  fill = c("#FF6B6B", "#4ECDC4"),
  cat.cex = 1.2,
  cex = 1.5
)
```
