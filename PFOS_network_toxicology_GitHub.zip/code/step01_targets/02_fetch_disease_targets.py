#!/usr/bin/env python3
"""
生精功能障碍相关基因多数据库整合脚本
=====================================
数据源：DisGeNET + CTD + OpenTargets
输出：三库并集基因列表（带来源标注），可直接用于与PFOS靶点取交集

依赖：pip install pandas requests tqdm

使用方式：
  python fetch_spermatogenesis_genes.py

作者：生信助手  日期：2026-07-22
"""

import os
import json
import time
import requests
import pandas as pd
from pathlib import Path
from tqdm import tqdm

# ============================================================
# 配置区
# ============================================================

OUTPUT_DIR = Path("disease_targets")
OUTPUT_DIR.mkdir(exist_ok=True)

# DisGeNET API（免费版，无需key）
DISGENET_API = "https://www.disgenet.org/api/gda/disease"
# 若你有DisGeNET账号，可在此填入API key获取更全数据
# 注册地址：https://www.disgenet.org/signup
DISGENET_API_KEY = ""  # 可选，留空则用匿名访问

# CTD 批量下载地址（完全免费无限制）
CTD_URL = "https://ctdbase.org/reports/CTD_diseases_genes.csv.gz"

# OpenTargets API（GraphQL）
OPENTARGETS_API = "https://api.platform.opentargets.org/api/v4/graphql"

# 生精功能障碍相关疾病关键词（英文，小写）
# 覆盖：不育、生精障碍、少精/无精、精子活力、睾丸功能障碍
KEYWORDS = [
    "infertility",
    "spermatogenesis",
    "oligospermia",
    "azoospermia",
    "male infertility",
    "spermatogenic failure",
    "spermatozoa",
    "spermatocyte",
    "seminiferous",
    "testicular dysfunction",
    "asthenozoospermia",
    "teratozoospermia",
]

# OpenTargets EFO ID 映射（已知的相关疾病EFO term）
# 查询地址：https://www.ebi.ac.uk/ols/ontologies/efo
OPENTARGETS_DISEASE_IDS = [
    "MONDO_0000384",   # male infertility
    "HP_0003251",      # male infertility
    "MONDO_0000919",   # oligospermia
    "MONDO_0000918",   # azoospermia
    "HP_0000044",      # hypogonadism
    "HP_0000027",      # azoospermia
    "HP_0000039",      # perineal hypospadias (可能关联)
]

# ============================================================
# 模块1：DisGeNET
# ============================================================

def fetch_disgenet():
    """
    DisGeNET API 获取疾病-基因关联。
    若本地已有 curated_gene_disease_associations.tsv，优先使用本地文件。
    """
    print("\n[DisGeNET] 开始获取数据...")

    # ---- 优先使用本地下载的TSV ----
    local_file = OUTPUT_DIR / "curated_gene_disease_associations.tsv"
    if local_file.exists():
        print(f"  [i] 检测到本地文件：{local_file}")
        df = pd.read_csv(local_file, sep="\t", low_memory=False)
    else:
        # 尝试API获取（匿名访问有限制，建议手动下载TSV）
        print("  [!] 未检测到本地TSV文件，尝试通过API获取...")
        print("  [i] 提示：DisGeNET API匿名访问数据有限，建议：")
        print("      1. 注册 https://www.disgenet.org/signup 获取API key")
        print("      2. 或手动下载 curated 数据集放到 {} 目录".format(OUTPUT_DIR))
        print("      下载地址（需登录）：https://www.disgenet.org/downloads")

        headers = {"Accept": "application/json"}
        if DISGENET_API_KEY:
            headers["Authorization"] = f"Bearer {DISGENET_API_KEY}"

        all_records = []
        # 按关键词逐一查询
        for kw in tqdm(KEYWORDS, desc="  DisGeNET API查询"):
            try:
                resp = requests.get(
                    f"{DISGENET_API}?disease_name={kw}",
                    headers=headers,
                    timeout=30,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    if isinstance(data, list) and len(data) > 0:
                        all_records.extend(data)
                else:
                    print(f"    [{kw}] HTTP {resp.status_code}")
                time.sleep(1)  # 礼貌延迟
            except Exception as e:
                print(f"    [{kw}] 错误：{e}")

        if not all_records:
            print("  [!] API未返回数据，请使用本地TSV文件方式。")
            return pd.DataFrame(), set()

        df = pd.DataFrame(all_records)

    # 过滤生精相关疾病
    disease_col = None
    for col in ["diseaseName", "disease_name", "name"]:
        if col in df.columns:
            disease_col = col
            break

    gene_col = None
    for col in ["geneSymbol", "gene_symbol", "symbol", "gene"]:
        if col in df.columns:
            gene_col = col
            break

    if disease_col is None or gene_col is None:
        print(f"  [!] 列名不匹配，现有列：{list(df.columns)}")
        return pd.DataFrame(), set()

    pattern = "|".join(KEYWORDS)
    mask = df[disease_col].astype(str).str.lower().str.contains(pattern, na=False)
    filtered = df[mask].copy()
    filtered["source_db"] = "DisGeNET"

    # 尝试保留证据分数（如有）
    score_col = None
    for col in ["score", "gda_score", "associationScore", "dsi", "dpi"]:
        if col in filtered.columns:
            score_col = col
            break

    keep_cols = [gene_col, disease_col, "source_db"]
    if score_col:
        keep_cols.append(score_col)
    keep_cols = [c for c in keep_cols if c in filtered.columns]

    result = filtered[keep_cols].rename(columns={
        gene_col: "gene_symbol",
        disease_col: "disease_name",
        score_col: "score",
    })

    genes = set(result["gene_symbol"].dropna().unique())
    result.to_csv(OUTPUT_DIR / "disgenet_genes.tsv", sep="\t", index=False)
    print(f"  [✓] DisGeNET 筛选到 {len(genes)} 个基因")
    return result, genes


# ============================================================
# 模块2：CTD
# ============================================================

def fetch_ctd():
    """
    CTD (Comparative Toxicogenomics Database) 批量下载 disease-gene 关联。
    完全免费，无需注册。
    """
    print("\n[CTD] 开始获取数据...")

    local_file = OUTPUT_DIR / "CTD_diseases_genes.csv.gz"

    if not local_file.exists():
        print(f"  [i] 下载 CTD 数据文件（约200MB+，请耐心等待）...")
        print(f"  [i] 下载地址：{CTD_URL}")
        try:
            resp = requests.get(CTD_URL, stream=True, timeout=300)
            resp.raise_for_status()
            total = int(resp.headers.get("content-length", 0))
            with open(local_file, "wb") as f, tqdm(
                total=total, unit="B", unit_scale=True, desc="  下载"
            ) as pbar:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)
                    pbar.update(len(chunk))
            print(f"  [✓] 下载完成：{local_file}")
        except Exception as e:
            print(f"  [!] 下载失败：{e}")
            print("  [i] 请手动下载并放到 {} 目录".format(OUTPUT_DIR))
            return pd.DataFrame(), set()
    else:
        print(f"  [i] 使用本地文件：{local_file}")

    # CTD文件前有注释行（以#开头），需要跳过
    print("  [i] 解析CTD文件...")
    df = pd.read_csv(local_file, compression="gzip", comment="#", low_memory=False)

    # CTD列名格式：Disease Name, Disease ID, Gene Symbol, ...
    # 重命名为统一格式
    col_map = {}
    for col in df.columns:
        col_lower = col.strip().lower()
        if "disease name" in col_lower:
            col_map[col] = "disease_name"
        elif "gene symbol" in col_lower:
            col_map[col] = "gene_symbol"
        elif "disease id" in col_lower:
            col_map[col] = "disease_id"
    df = df.rename(columns=col_map)

    if "disease_name" not in df.columns or "gene_symbol" not in df.columns:
        print(f"  [!] 列名解析失败，现有列：{list(df.columns)}")
        return pd.DataFrame(), set()

    # 过滤生精相关疾病
    pattern = "|".join(KEYWORDS)
    mask = df["disease_name"].astype(str).str.lower().str.contains(pattern, na=False)
    filtered = df[mask].copy()
    filtered["source_db"] = "CTD"
    filtered = filtered.dropna(subset=["gene_symbol"])
    # 去掉CTD中的"-"占位符
    filtered = filtered[filtered["gene_symbol"] != "-"]

    keep_cols = ["gene_symbol", "disease_name", "source_db"]
    if "disease_id" in filtered.columns:
        keep_cols.append("disease_id")
    keep_cols = [c for c in keep_cols if c in filtered.columns]

    result = filtered[keep_cols].drop_duplicates()
    genes = set(result["gene_symbol"].unique())
    result.to_csv(OUTPUT_DIR / "ctd_genes.tsv", sep="\t", index=False)
    print(f"  [✓] CTD 筛选到 {len(genes)} 个基因")
    return result, genes


# ============================================================
# 模块3：OpenTargets
# ============================================================

def fetch_opentargets():
    """
    OpenTargets GraphQL API 按疾病EFO ID批量获取关联基因。
    完全开放，无需认证。
    """
    print("\n[OpenTargets] 开始获取数据...")

    all_results = []

    for disease_id in tqdm(OPENTARGETS_DISEASE_IDS, desc="  OpenTargets查询"):
        # OpenTargets API 单次最多返回 target BSize 个结果，需要分页
        index = 0
        page_size = 5000

        while True:
            query = """
            query GetAssociatedTargets($diseaseId: String!, $index: Int!, $size: Int!) {
              disease(efoId: $diseaseId) {
                id
                name
                associatedTargets(page: {index: $index, size: $size}) {
                  count
                  rows {
                    target {
                      id
                      approvedSymbol
                      approvedName
                    }
                    score
                  }
                }
              }
            }
            """

            variables = {
                "diseaseId": disease_id,
                "index": index,
                "size": page_size,
            }

            try:
                resp = requests.post(
                    OPENTARGETS_API,
                    json={"query": query, "variables": variables},
                    headers={"Content-Type": "application/json"},
                    timeout=60,
                )
                if resp.status_code != 200:
                    print(f"    [{disease_id}] HTTP {resp.status_code}")
                    break

                data = resp.json()
                disease_data = data.get("data", {}).get("disease")

                if disease_data is None:
                    # EFO ID 可能已更新，尝试用MONDO或HP格式
                    print(f"    [{disease_id}] 未找到该疾病ID，跳过")
                    break

                disease_name = disease_data.get("name", "")
                associated = disease_data.get("associatedTargets", {})
                rows = associated.get("rows", [])
                total_count = associated.get("count", 0)

                if not rows:
                    break

                for row in rows:
                    target = row.get("target", {})
                    all_results.append({
                        "gene_symbol": target.get("approvedSymbol", ""),
                        "gene_name": target.get("approvedName", ""),
                        "disease_name": disease_name,
                        "disease_id": disease_id,
                        "score": row.get("score", None),
                        "source_db": "OpenTargets",
                    })

                # 是否还有更多数据
                if index + page_size >= total_count:
                    break
                index += page_size
                time.sleep(0.5)

            except Exception as e:
                print(f"    [{disease_id}] 错误：{e}")
                break

    if not all_results:
        print("  [!] OpenTargets 未返回数据")
        return pd.DataFrame(), set()

    result = pd.DataFrame(all_results)
    result = result.dropna(subset=["gene_symbol"])
    result = result[result["gene_symbol"] != ""]

    # 按关联评分排序，保留每个基因的最高分
    result = result.sort_values("score", ascending=False).drop_duplicates(
        subset=["gene_symbol", "disease_id"], keep="first"
    )

    genes = set(result["gene_symbol"].unique())
    result.to_csv(OUTPUT_DIR / "opentargets_genes.tsv", sep="\t", index=False)
    print(f"  [✓] OpenTargets 筛选到 {len(genes)} 个基因")
    return result, genes


# ============================================================
# 模块4：整合三库
# ============================================================

def merge_results(disgenet_df, ctd_df, ot_df, disgenet_genes, ctd_genes, ot_genes):
    """三库合并，标注来源，输出最终基因列表。"""
    print("\n[整合] 合并三库数据...")

    all_genes = disgenet_genes | ctd_genes | ot_genes
    print(f"  [i] DisGeNET: {len(disgenet_genes)} | CTD: {len(ctd_genes)} | OpenTargets: {len(ot_genes)}")
    print(f"  [i] 并集总数: {len(all_genes)}")

    # 构建来源标注表
    records = []
    for gene in sorted(all_genes):
        sources = []
        if gene in disgenet_genes:
            sources.append("DisGeNET")
        if gene in ctd_genes:
            sources.append("CTD")
        if gene in ot_genes:
            sources.append("OpenTargets")
        records.append({
            "gene_symbol": gene,
            "source_count": len(sources),
            "sources": ";".join(sources),
        })

    merged_df = pd.DataFrame(records)

    # 统计各来源覆盖情况
    print(f"\n  === 来源统计 ===")
    print(f"  仅DisGeNET:      {len(disgenet_genes - ctd_genes - ot_genes)}")
    print(f"  仅CTD:           {len(ctd_genes - disgenet_genes - ot_genes)}")
    print(f"  仅OpenTargets:   {len(ot_genes - disgenet_genes - ctd_genes)}")
    print(f"  DisGeNET∩CTD:    {len(disgenet_genes & ctd_genes)}")
    print(f"  DisGeNET∩OT:     {len(disgenet_genes & ot_genes)}")
    print(f"  CTD∩OT:          {len(ctd_genes & ot_genes)}")
    print(f"  三库交集:        {len(disgenet_genes & ctd_genes & ot_genes)}")

    # 按来源数量降序排列
    merged_df = merged_df.sort_values(["source_count", "gene_symbol"], ascending=[False, True])

    # 输出完整列表
    merged_df.to_csv(OUTPUT_DIR / "spermatogenesis_genes_merged.tsv", sep="\t", index=False)

    # 输出纯基因列表（每行一个基因，方便后续分析）
    with open(OUTPUT_DIR / "spermatogenesis_genes_list.txt", "w") as f:
        for gene in merged_df["gene_symbol"]:
            f.write(gene + "\n")

    # 输出多库支持的高置信基因（>=2个来源）
    high_conf = merged_df[merged_df["source_count"] >= 2]
    high_conf.to_csv(OUTPUT_DIR / "spermatogenesis_genes_high_confidence.tsv", sep="\t", index=False)
    with open(OUTPUT_DIR / "spermatogenesis_genes_high_confidence.txt", "w") as f:
        for gene in high_conf["gene_symbol"]:
            f.write(gene + "\n")

    print(f"\n  [✓] 输出文件：")
    print(f"      - disease_targets/spermatogenesis_genes_merged.tsv         （完整合并表）")
    print(f"      - disease_targets/spermatogenesis_genes_list.txt            （纯基因列表）")
    print(f"      - disease_targets/spermatogenesis_genes_high_confidence.tsv （≥2库支持）")
    print(f"      - disease_targets/spermatogenesis_genes_high_confidence.txt （高置信基因列表）")
    print(f"      - disease_targets/disgenet_genes.tsv   （DisGeNET明细）")
    print(f"      - disease_targets/ctd_genes.tsv        （CTD明细）")
    print(f"      - disease_targets/opentargets_genes.tsv（OpenTargets明细）")

    print(f"\n  [i] 高置信基因数（≥2库支持）: {len(high_conf)}")
    return merged_df


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 60)
    print("  生精功能障碍相关基因 —— 多数据库整合")
    print("  数据源：DisGeNET + CTD + OpenTargets")
    print("=" * 60)

    # 1. DisGeNET
    disgenet_df, disgenet_genes = fetch_disgenet()

    # 2. CTD
    ctd_df, ctd_genes = fetch_ctd()

    # 3. OpenTargets
    ot_df, ot_genes = fetch_opentargets()

    # 4. 合并
    merged = merge_results(disgenet_df, ctd_df, ot_df,
                           disgenet_genes, ctd_genes, ot_genes)

    print("\n" + "=" * 60)
    print("  完成！")
    print(f"  最终基因数：{len(merged)}")
    print(f"  高置信基因数（≥2库）：{len(merged[merged['source_count']>=2])}")
    print("=" * 60)
    print("\n  下一步：将 spermatogenesis_genes_list.txt 与 PFOS 靶点列表取交集")
    print("  建议：网络毒理学分析优先使用 high_confidence 版本（≥2库支持）")


if __name__ == "__main__":
    main()
