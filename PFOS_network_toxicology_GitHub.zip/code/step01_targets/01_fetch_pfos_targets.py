#!/usr/bin/env python3
"""
Step 01: 获取PFOS靶点基因
==========================
输入（用户提供的手动下载文件，均为xlsx格式但扩展名为csv）:
  - CTD PFOS基因导出文件（CTD网页: Chemicals → C076994 → Genes，下载csv）
  - SwissTargetPrediction结果（swisstargetprediction.ch, PFOS SMILES, Homo sapiens）

输出:
  - data_analysis/pfos_targets_ctd.csv     CTD靶点（人类基因过滤后）
  - data_analysis/pfos_targets_all.csv     CTD ∪ STP 最终PFOS靶点列表（n=8788）

⚠ 复现说明：
  原始分析中CTD导出文件为网页端限定 Homo sapiens 的版本（5,846基因）。
  CTD数据库持续更新，且不同物种过滤方式会导致小幅漂移：本脚本用mygene按
  taxid==9606过滤（约8,787基因），与存档列表相差2个基因（TPCN1、ELOVL2），
  对最终389交集无实质影响。论文报告数字以存档数据为准（8,788）。

依赖: pandas openpyxl mygene
"""
import pandas as pd
from pathlib import Path

# ============ 配置 ============
CTD_FILE = "data/6a646c440a28304fb4e3162f_1784966211774_ctd_c076994_genes_20260725034548.csv"
STP_FILE = "data/6a646c438fd93120c742a7cd_1784966211775_swisstargetprediction.csv"
OUT_DIR = Path("data")
# 存档的最终列表（论文使用），如存在则作为对照
ARCHIVED_LIST = OUT_DIR / "pfos_targets_all.csv"

# 线虫GeneID范围（CTD多物种条目）
WORM_ID_RANGE = (170000, 300000)


def parse_ctd(path):
    """解析CTD基因导出文件（xlsx），仅保留人类基因。"""
    df = pd.read_excel(path)  # CTD导出的csv实为xlsx
    df.columns = [c.strip() for c in df.columns]
    n_raw = len(df)

    # 1) 去除含点号的基因符号（线虫等模式动物命名，如C02B4.3）
    df = df[~df["Gene Symbol"].astype(str).str.contains(r"\.")]
    # 2) 去除线虫GeneID范围
    df = df[~df["Gene ID"].between(*WORM_ID_RANGE)]

    # 3) 物种过滤：用mygene查Entrez ID的taxid，仅保留人类(9606)
    import mygene
    mg = mygene.MyGeneInfo()
    ids = df["Gene ID"].astype(int).tolist()
    hits = mg.querymany(ids, scopes="entrezgene", fields="taxid",
                        species="human", silent=True)
    human_ids = {int(h["query"]) for h in hits if h.get("taxid") == 9606}
    df = df[df["Gene ID"].astype(int).isin(human_ids)].copy()
    df["keep"] = True
    print(f"CTD: {n_raw} raw → {len(df)} human genes")

    # 与存档列表对照（可选）
    if ARCHIVED_LIST.exists():
        arch = set(pd.read_csv(ARCHIVED_LIST)["GeneSymbol"])
        print(f"  存档列表: {len(arch)} | 本次重合: {len(arch & set(df['Gene Symbol']))}"
              f" | 漂移: {sorted(arch ^ set(df['Gene Symbol']))[:10]}")
    return df.reset_index(drop=True)


def parse_stp(path):
    """解析SwissTargetPrediction结果（取Common name列）。"""
    df = pd.read_excel(path)
    genes = df["Common name"].astype(str).str.strip()
    genes = genes[~genes.eq("nan")]
    print(f"SwissTargetPrediction: {genes.nunique()} targets")
    return set(genes)


def main():
    ctd = parse_ctd(CTD_FILE)
    ctd.to_csv(OUT_DIR / "pfos_targets_ctd.csv", index=False)

    stp_genes = parse_stp(STP_FILE)
    all_genes = set(ctd["Gene Symbol"]) | stp_genes
    print(f"\n最终PFOS靶点: {len(all_genes)} (CTD {len(ctd)} ∪ STP {len(stp_genes)})")

    pd.DataFrame({"GeneSymbol": sorted(all_genes)}).to_csv(
        OUT_DIR / "pfos_targets_all.csv", index=False)
    print(f"已保存 → {OUT_DIR / 'pfos_targets_all.csv'}")


if __name__ == "__main__":
    main()
