# Code — PFOS network toxicology study (v3.4, PLOS submission)

Analysis code for: **Network toxicology integration of multi-database mining, machine learning, and molecular
docking computationally prioritises candidate genes potentially linking PFOS exposure to spermatogenic dysfunction**

All numbers in the manuscript map to the outputs listed in `REPRODUCIBILITY.md` (repo root).

## Pipeline

```
step01_targets/       CTD / SwissTargetPrediction / disease target collection
step02_network/       389 intersection, STRING v12.0 PPI, topology, Louvain modules
step03_geo_ml/        GSE45885 processing, DEG analysis, LOOCV, cross-species comparison
step04_docking/       receptor/ligand preparation, Vina docking
step05_figures_reports/  figure generation (legacy v2 scripts superseded by updates_v3)
step06_qc/            QC scripts (20/21/22); outputs in results/
updates_v3/           scripts superseding archived versions (see REPRODUCIBILITY.md)
```

## Key scripts (v3.4)

| Script | Purpose | Output |
|---|---|---|
| `updates_v3/11_ml_routeA_frozen.py` | frozen multi-seed ML consensus (5 seeds, 140 candidates) | `results/ml_routeA_frozen.json` |
| `updates_v3/12_cv_consensus_panel.py` | 5-fold CV + LOOCV of the 4-gene panel | `results/cv_panel4_real.json`, `results/loocv_panel4.json` |
| `updates_v3/13_prepare_receptors_new_panel.py` | AlphaFold v6 receptor preparation (GAPDHS/COX6B2/REC8) | PDBQT files |
| `updates_v3/14_dock_new_panel.py` | Vina docking of GAPDHS and COX6B2 | out_PDBQT |
| `updates_v3/10_deg_medaka_FULL.py` | medaka full-file DEG (correct dose-based grouping) | `results/TableS3_medaka_DEG_recalculated.csv`, `results/TableS3_medaka_DEG_matched.csv` |

## Notes

- Legacy scripts under `step01-06` reproduce the original GEO-RMA screening pipeline and are retained for
  provenance; the numbers reported in the manuscript derive from the v3.4 pipeline documented in
  `REPRODUCIBILITY.md`.
- The medaka DEG script (`10_deg_medaka_FULL.py`) was corrected in v3.4: biological replicates are encoded
  A-C and dose groups as 1 (0 mg/L), 2 (0.002 mg/L), 3 (0.02 mg/L) in the sample identifiers; dose-1 samples
  of both lineages serve as the pooled control.
- Docking: exhaustiveness 32, boxes centred on whole-protein geometric centres, except FUS (site-specific
  at PDB 6G99 zinc-finger pocket; four random seeds reported).
