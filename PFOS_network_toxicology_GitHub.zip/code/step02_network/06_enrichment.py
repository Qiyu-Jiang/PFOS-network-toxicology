#!/usr/bin/env python3
"""
Step 06: GO/KEGG富集分析 (Enrichr)
====================================
对两组基因集分别做富集:
  - 379交集基因
  - 101 hub基因
库: KEGG_2021_Human, GO_Biological_Process_2023,
    GO_Molecular_Function_2023, GO_Cellular_Component_2023
共 2 × 4 = 8组结果。显著性阈值: BH校正 p < 0.05。

输入:  data_analysis/pfos_disease_intersection.csv
       data_analysis/ppi_hub_genes.csv
输出:  data_analysis/enrichment/intersect379_{KEGG,GO_BP,GO_MF,GO_CC}.csv
       data_analysis/enrichment/hub101_{KEGG,GO_BP,GO_MF,GO_CC}.csv
       data_analysis/enrichment/kegg_enrichment_plot.png
       data_analysis/enrichment/go_bp_enrichment_plot.png

依赖: gseapy (pip install gseapy), matplotlib
注意: organism='human'（小写）；8组分批跑避免API超时。
"""
import pandas as pd
import gseapy as gp
from pathlib import Path

BASE = Path("data")
OUT = BASE / "enrichment"
OUT.mkdir(exist_ok=True)

GENE_SETS = ["KEGG_2021_Human",
             "GO_Biological_Process_2023",
             "GO_Molecular_Function_2023",
             "GO_Cellular_Component_2023"]
NAME_MAP = {"KEGG_2021_Human": "KEGG",
            "GO_Biological_Process_2023": "GO_BP",
            "GO_Molecular_Function_2023": "GO_MF",
            "GO_Cellular_Component_2023": "GO_CC"}
ADJ_P_CUTOFF = 0.05

GROUPS = [
    ("intersect379", BASE / "pfos_disease_intersection.csv"),
    ("hub101", BASE / "ppi_hub_genes.csv"),
]


def run_enrichr(gene_list, tag):
    """对一组基因跑4个库的Enrichr，分别保存显著条目。"""
    for lib in GENE_SETS:
        print(f"  [{tag}] {lib} ...", end=" ", flush=True)
        enr = gp.enrichr(gene_list=gene_list,
                         gene_sets=[lib],
                         organism="human",
                         outdir=None,
                         no_plot=True,
                         cutoff=ADJ_P_CUTOFF)
        df = enr.results
        sig = df[df["Adjusted P-value"] < ADJ_P_CUTOFF].copy()
        sig.to_csv(OUT / f"{tag}_{NAME_MAP[lib]}.csv", index=False)
        print(f"{len(sig)} 条显著条目")


def plot_top(tag, lib_name, csv_name, top_n=15):
    """横向条形图: top-N显著条目。"""
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "savefig.dpi": 300,
                         "savefig.bbox": "tight"})
    df = pd.read_csv(OUT / csv_name).head(top_n).iloc[::-1]
    df["label"] = df["Term"].str.replace(r"\s*\(GO:\d+\)", "", regex=True)
    fig, ax = plt.subplots(figsize=(6.69, 0.28 * len(df) + 1))
    ax.barh(df["label"], -df["Adjusted P-value"].apply(lambda x: 0 if x == 0 else __import__("math").log10(x)))
    ax.set_xlabel("-log10(Adjusted P-value)")
    ax.set_title(f"{tag} - {lib_name} top {len(df)}")
    fig.savefig(OUT / f"{tag}_{NAME_MAP.get(lib_name, lib_name)}_plot.png")
    plt.close(fig)


def main():
    for tag, path in GROUPS:
        genes = pd.read_csv(path)["GeneSymbol"].dropna().astype(str).tolist()
        print(f"\n富集分析: {tag} (n={len(genes)})")
        run_enrichr(genes, tag)

    # 汇总输出
    print("\n── 富集结果汇总 ──")
    for tag, _ in GROUPS:
        for lib in GENE_SETS:
            f = OUT / f"{tag}_{NAME_MAP[lib]}.csv"
            if f.exists():
                n = len(pd.read_csv(f))
                print(f"  {tag}_{NAME_MAP[lib]}: {n} 条")


if __name__ == "__main__":
    main()
