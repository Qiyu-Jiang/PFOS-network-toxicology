#!/usr/bin/env python3
"""
Step 04: PFOS靶点 ∩ 疾病靶点 → 交集基因
==========================================
输入:
  - data_analysis/pfos_targets_all.csv        (8,788 PFOS靶点)
  - data_analysis/disease_targets_merged.csv  (1053疾病靶点, 含source_count/sources/OT_score)
  - data_analysis/pfos_targets_ctd.csv        (CTD明细, 提供Interaction Count)

输出:
  - data_analysis/pfos_disease_intersection.csv  (389交集基因, 带来源注释)

依赖: pandas
"""
import pandas as pd
from pathlib import Path

BASE = Path("data")


def main():
    pfos = pd.read_csv(BASE / "pfos_targets_all.csv")
    dis = pd.read_csv(BASE / "disease_targets_merged.csv")
    ctd = pd.read_csv(BASE / "pfos_targets_ctd.csv")[["Gene Symbol", "Interaction Count"]]
    stp = pd.read_excel(
        "data/6a646c438fd93120c742a7cd_1784966211775_swisstargetprediction.csv"
    )["Common name"].astype(str)

    p_set = set(pfos["GeneSymbol"])
    d_set = set(dis["GeneSymbol"])
    inter = p_set & d_set
    print(f"PFOS靶点 {len(p_set)} ∩ 疾病靶点 {len(d_set)} = {len(inter)} 交集基因")

    # 组装注释列
    dis_idx = dis.set_index("GeneSymbol")
    ctd_idx = ctd.set_index("Gene Symbol")["Interaction Count"]
    stp_set = set(stp)

    rows = []
    for g in sorted(inter):
        d = dis_idx.loc[g]
        src = "CTD" if g in ctd_idx.index else ""
        if not src and g in stp_set:
            src = "SwissTargetPrediction"
        elif g in stp_set:
            src += ";SwissTargetPrediction"
        ic = ctd_idx.get(g, "")
        rows.append({
            "GeneSymbol": g,
            "PFOS_source": src,
            "CTD_interaction_count": ic,
            "disease_sources": d["sources"],
            "disease_source_count": d["source_count"],
            "OT_score": d["OT_score"],
        })

    out = pd.DataFrame(rows)
    out.to_csv(BASE / "pfos_disease_intersection.csv", index=False)
    print(f"已保存 → {BASE / 'pfos_disease_intersection.csv'}")

    # 摘要
    n_core = (out["disease_source_count"] == 3).sum()
    print(f"其中三库核心基因(疾病端MalaCards+CTD+OpenTargets全命中): {n_core}")


if __name__ == "__main__":
    main()
