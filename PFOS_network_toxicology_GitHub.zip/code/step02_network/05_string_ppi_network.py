#!/usr/bin/env python3
"""
Step 05: STRING PPI网络分析
=============================
流程:
  1. 379交集基因提交STRING API (v12.0, required_score=400, species=9606)
  2. NetworkX计算拓扑指标: Degree/Betweenness/Closeness/Eigenvector
  3. Hub基因 = Degree ≥ 2 × median(Degree)   [median=7 → 阈值≥14 → 101个hub]
  4. Louvain社区检测 (resolution=1.0) → 9个功能模块

输入:  data_analysis/pfos_disease_intersection.csv
输出:
  - data_analysis/string_ppi_edges.csv   STRING边表(score≥0.4)
  - data_analysis/ppi_topology.csv       全部节点拓扑指标+排名
  - data_analysis/ppi_hub_genes.csv      101个hub基因
  - data_analysis/ppi_key_genes.csv      hub基因完整指标(含排名)
  - data_analysis/ppi_modules.csv        Louvain模块(编号按size降序)

依赖: pandas requests networkx python-louvain
"""
import requests
import pandas as pd
import networkx as nx
from pathlib import Path

BASE = Path("data")
STRING_URL = "https://string-db.org/api/tsv/network"
SPECIES = 9606          # Homo sapiens
REQUIRED_SCORE = 400    # confidence ≥ 0.4


def fetch_string_edges(genes):
    """调用STRING network API获取边表。"""
    identifiers = "%0d".join(genes)
    params = {
        "identifiers": identifiers,
        "species": SPECIES,
        "required_score": REQUIRED_SCORE,
        "caller_identity": "pfos_network_toxicology",
    }
    r = requests.post(STRING_URL, data=params, timeout=300)
    r.raise_for_status()
    from io import StringIO
    edges = pd.read_csv(StringIO(r.text), sep="\t")
    print(f"STRING返回 {len(edges)} 条边 (score≥{REQUIRED_SCORE/1000})")
    return edges


def main():
    inter = pd.read_csv(BASE / "pfos_disease_intersection.csv")
    genes = inter["GeneSymbol"].tolist()

    # ── 1. STRING API ──
    edges = fetch_string_edges(genes)
    edges.to_csv(BASE / "string_ppi_edges.csv", index=False)

    # ── 2. 构建网络与拓扑指标 ──
    G = nx.Graph()
    for _, r in edges.iterrows():
        G.add_edge(r["preferredName_A"], r["preferredName_B"],
                   weight=r["score"])
    print(f"网络: {G.number_of_nodes()} 节点 / {G.number_of_edges()} 边")

    # 最大连通分量
    components = sorted(nx.connected_components(G), key=len, reverse=True)
    largest = G.subgraph(components[0]).copy()
    print(f"最大连通分量: {largest.number_of_nodes()} 节点 "
          f"(丢弃 {len(components)-1} 个小分量, 共 "
          f"{G.number_of_nodes()-largest.number_of_nodes()} 个孤立/小节点)")

    deg = dict(largest.degree())
    bet = nx.betweenness_centrality(largest)
    clo = nx.closeness_centrality(largest)
    eig = nx.eigenvector_centrality(largest, max_iter=1000)

    topo = pd.DataFrame({
        "GeneSymbol": list(largest.nodes()),
        "Degree": [deg[n] for n in largest.nodes()],
        "Betweenness": [bet[n] for n in largest.nodes()],
        "Closeness": [clo[n] for n in largest.nodes()],
        "Eigenvector": [eig[n] for n in largest.nodes()],
    }).sort_values("Degree", ascending=False)

    # 排名 (rank=1为最高, 归一化为百分位)
    for col in ["Degree", "Betweenness", "Closeness", "Eigenvector"]:
        topo[f"{col}_rank"] = topo[col].rank(ascending=False, pct=True)

    topo.to_csv(BASE / "ppi_topology.csv", index=False)

    # ── 3. Hub基因: Degree ≥ 2×median ──
    med = topo["Degree"].median()
    threshold = 2 * med
    hubs = topo[topo["Degree"] >= threshold].copy()
    hubs.to_csv(BASE / "ppi_hub_genes.csv", index=False)
    hubs.to_csv(BASE / "ppi_key_genes.csv", index=False)
    print(f"Degree median = {med} → hub阈值 ≥ {threshold} → {len(hubs)} 个hub基因")

    # ── 4. Louvain社区检测 ──
    import community as community_louvain  # python-louvain
    partition = community_louvain.best_partition(largest, resolution=1.0,
                                                 random_state=42)
    modularity = community_louvain.modularity(partition, largest)
    print(f"Louvain模块数: {len(set(partition.values()))}, "
          f"模块度: {modularity:.4f}")

    mod_rows = []
    for m in sorted(set(partition.values())):
        members = [n for n, mm in partition.items() if mm == m]
        sub = largest.subgraph(members)
        degs = {n: sub.degree(n) for n in members}
        hub_gene = max(degs, key=degs.get)
        mod_rows.append({
            "module": m,
            "size": len(members),
            "edges": sub.number_of_edges(),
            "density": round(nx.density(sub), 4),
            "hub_gene": hub_gene,
            "genes": ";".join(sorted(members)),
        })
    mods = pd.DataFrame(mod_rows).sort_values("size", ascending=False)
    mods["module"] = range(1, len(mods) + 1)  # 按size重新编号
    mods.to_csv(BASE / "ppi_modules.csv", index=False)
    print(mods[["module", "size", "edges", "hub_gene"]].to_string(index=False))


if __name__ == "__main__":
    main()
